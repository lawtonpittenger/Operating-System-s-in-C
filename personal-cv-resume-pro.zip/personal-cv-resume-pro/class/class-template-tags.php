<?php
/**
 * Custom template tags for this theme
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package Diet_Shop
 */

class personal_cv_resume_Post_Meta {
	/**
	 * Function that is run after instantiation.
	 *
	 * @return void
	 */
	public function __construct() {
		
		
		add_action( 'personal_cv_resume_do_tags', array( $this, 'social_share_options' ),20 );
		add_action( 'personal_cv_resume_do_tags', array( $this, 'render_tags_list' ),5 );
		
		add_action( 'personal_cv_resume_site_content_type', array( $this, 'render_meta_list' ), 10, 1 );
		add_action( 'personal_cv_resume_meta_info', array( $this, 'render_meta_list' ), 10, 2 );
		
		add_action( 'render_category_list', array( $this, 'render_category_list' ), 10, 2 );
	}

	public function render_category_list(){
		
		$markup = '<li class="meta category">';
		$markup .= get_the_category_list( ', ', get_the_ID() );
		$markup .= '</li>';
		
		echo $markup;		
		
	}
	/**
	 * Render meta list.
	 *
	 * @param array $order the order array. Passed through the action parameter.
	 */
	public function render_meta_list( $order, $wrp_class = '' ) {
		
		global $post;
			
		if ( ! is_array( $order ) || empty( $order ) || isset( $order['hide_meta'] ) ) {
			
			return;
		}
		$order  = $this->sanitize_order_array( $order );
		$markup = '';
		$markup .= '<div class="post-meta-wrap'.esc_attr( $wrp_class ).'">';
		
		//$markup .= $this->get_avatar( $order );

		$markup .= '<ul class="post-meta d-flex align-items-center">';
		foreach ( $order as $meta ) {
			switch ( $meta ) {
				case 'author':

     				$author_id		= !empty(get_the_author_meta( 'ID' ))? get_the_author_meta( 'ID' ) : $post->post_author;
					$markup .= '<li class="post-by">';
					$markup .= ' <span>'. esc_html( personal_cv_resume_get_option( '__pcr_by_text' ) ) .'</span> ';
					$markup .= '<a href="' . esc_url( get_author_posts_url( $author_id ) ) . '">' . esc_html( get_the_author_meta('display_name', $author_id) ) . '</a>';
					$markup .= '</li>';
					break;
				case 'avatar':

					$markup .= '<li class="post-by">';
					$markup .= $this->get_avatar( $order );
					$markup .= '</li>';
					break;	

				case 'date':
					$markup .= '<li class="meta date posted-on">';
					$markup .= esc_html( personal_cv_resume_get_option( '__pcr_posted_on' ) ).' ' ;
					$markup .= $this->get_time_tags();
					$markup .= '</li>';
					break;
				case 'category':
					$markup .= '<li class="meta category">';
					$markup .= esc_html( personal_cv_resume_get_option( '__pcr_posted_in' ) );
					$markup .= ' '. get_the_category_list( ', ', get_the_ID() );
					$markup .= '</li>';
					break;
				case 'comments':
					$comments = $this->get_comments();
					if ( empty( $comments ) ) {
						break;
					}
					$markup .= '<li class="meta comments">';
					$markup .= $comments;
					$markup .= '</li>';
					break;
				default:
					break;
			}
		}
		$markup .= '</ul>';
		
		$markup .= '</div>';

		echo wp_kses( $markup, $this->alowed_tags() );
	}
	
	
	/**
	 * Makes sure there's a valid meta order array.
	 *
	 * @param array $order meta order array.
	 *
	 * @return mixed
	 */
	private function sanitize_order_array( $order ) {
		$allowed_order_values = array(
			'avatar',
			'author',
			'date',
			'category',
			'comments',
			
		);
		foreach ( $order as $index => $value ) {
			if ( ! in_array( $value, $allowed_order_values ) ) {
				unset( $order[ $index ] );
			}
		}

		return $order;
	}
	
	/**
	 * Get the get_avatar a link.
	 *
	 * @return string
	 */
	private function get_avatar( $order ) {
		
		if( !empty( $order ) && in_array( 'avatar',$order ) )
		return ' <div class="tb-cell avatar"><a href="'.esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ).'" class="avatar_round"> '.get_avatar( get_the_author_meta('user_email'), $size = '60').' </a></div>';
		

	}
	/**
	 * Get the comments with a link.
	 *
	 * @return string
	 */
	private function get_comments() {
		$comments_number = get_comments_number();
		if ( ! comments_open() ) {
			return '';
		}
		if ( $comments_number == 0 ) {
			return '';
		} else {
			/* translators: %s: number of comments */
			$comments = sprintf( _n( '%s Comment', '%s Comments', $comments_number, 'personal-cv-resume' ), $comments_number );
		}

		return '<a href="' . esc_url( get_comments_link() ) . '">' . esc_html( $comments ) . '</a>';
	}

	

	/**
	 * Render the tags list.
	 */
	public function render_tags_list( $meta = array() ) {
		if( in_array('tag',$meta) ):
			$tags = get_the_tags();
			if ( ! is_array( $tags ) ) {
				return;
			}
			$html  = '<div class="pcv-tags-list col-md-6 col-12 d-flex align-items-center">';
			$html .= '<span>' . esc_html( personal_cv_resume_get_option( '__pcr_tags_text' ) ) . ' :</span>';
			foreach ( $tags as $tag ) {
				$tag_link = get_tag_link( $tag->term_id );
				$html    .= '<a href=' . esc_url( $tag_link ) . ' title="' . esc_attr( $tag->name ) . '" class=' . esc_attr( $tag->slug ) . ' rel="tag"><i class="tag-icon fa fa-tag"></i>';
				$html    .= esc_html( $tag->name ) . '</a>';
			}
			$html .= ' </div> ';
			echo wp_kses_post( $html );
		endif;	
	}

	/**
	 * Post Single Posts Navigation 
	 *
	 * @since 1.0.0
	 */
	function social_share_options( ) {

		echo '<div class="share-box col-md-6 col-12 d-flex align-items-center">';
		if( !empty( personal_cv_resume_get_option( '__posts_share' ) ) ){ 
		$img = wp_get_attachment_url( get_post_thumbnail_id( get_the_ID()) );
	?>
        
	        <h6><?php echo esc_html( personal_cv_resume_get_option( '__pcr_share_this' ) );?></h6>
	        
	        <a href="<?php echo esc_url( 'https://twitter.com/share?url='.get_permalink(get_the_ID()).'&text='.get_the_title() );?>" title="<?php echo esc_html__('Share on Twitter','personal-cv-resume');?>" target="_blank" class="pure-button button-twitter"><i class="fab fa-twitter"></i></a> 
	        
	        
	        <a href="<?php echo esc_url( 'http://www.facebook.com/sharer.php?u='.get_permalink(get_the_ID()).'&amp;title='.get_the_title());?>" title="<?php echo esc_html__('Share on Facebook','personal-cv-resume');?>" target="_blank" class="pure-button button-facebook"><i class="fab fa-facebook"></i></a> 
	        
	       
	        <a href="<?php echo esc_url( 'http://www.stumbleupon.com/submit?url='.get_permalink(get_the_ID()).'&amp;title='.get_the_title() );?>" title="<?php echo esc_html__('Share on Stumbleupon','personal-cv-resume');?>" target="_blank" class="pure-button button-stumbleupon"><i class="fab fa-stumbleupon"></i></a> 
	        
	       
	        <a href="<?php echo esc_url( ' http://www.linkedin.com/shareArticle?mini=true&url='.get_permalink(get_the_ID()).'&title='. get_the_title() );?>" title="<?php echo esc_html__('Share on LinkedIn','personal-cv-resume');?>" target="_blank" class="pure-button button-linkedin"><i class="fab fa-linkedin"></i> </a>

	         <a href="<?php echo esc_url( 'http://pinterest.com/pin/create/button/?url='.get_permalink(get_the_ID()).'&media='.esc_url( $img ).'&description='.get_the_title());?>" class="pure-button button-pinterest" target="_blank" title="<?php echo esc_html__('Share on Pinterest','personal-cv-resume');?>"> <i class="fab fa-pinterest"></i></a> 
	    <?php };?>     
        </div>
    <?php
		
	} 

	/**
	 * Get <time> tags.
	 *
	 * @return string
	 */
	private function get_time_tags() {
		$time = '<time class="entry-date published" datetime="' . esc_attr( get_the_date( 'c' ) ) . '" content="' . esc_attr( get_the_date( 'Y-m-d' ) ) . '">' . esc_html( get_the_date() ) . '</time>';
		if ( get_the_time( 'U' ) === get_the_modified_time( 'U' ) ) {
			return $time;
		}
		$time .= '<time class="updated" datetime="' . esc_attr( get_the_modified_date( 'c' ) ) . '">' . esc_html( get_the_modified_date() ) . '</time>';

		return $time;
	}
	
	private function alowed_tags(){
		
		if( function_exists('personal_cv_resume_alowed_tags') ){ 
			return personal_cv_resume_alowed_tags(); 
		}else{
			return array();	
		}
		
	}
	
}

$personal_cv_resume_post_meta = new personal_cv_resume_Post_Meta();