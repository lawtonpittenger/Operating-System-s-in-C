<?php
/**
 * The Site Theme Header Class 
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package emart-shop
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
class personal_cv_resume_Footer_Layout{
	/**
	 * Function that is run after instantiation.
	 *
	 * @return void
	 */
	public function __construct() {
		
		add_action('personal_cv_resume_site_footer', array( $this, 'site_footer_container_before' ), 5);
		add_action('personal_cv_resume_site_footer', array( $this, 'site_footer_widgets' ), 10);
		add_action('personal_cv_resume_site_footer', array( $this, 'site_footer_info' ), 80);
		add_action('personal_cv_resume_site_footer', array( $this, 'site_footer_container_after' ), 998);

		add_action('wp_footer', array( $this, 'pcr_body_loader' ), 999);

		
	}

	function pcr_body_loader( ) {
		if( empty(personal_cv_resume_get_option( '__page_loading' )) ) return false;
		?>
		<div id="loader-wrapper">
			<div id="loader">
			    <span class="loader-inner"></span>
			</div>
		</div>
		<?php
		}

	/**
	* diet_shop foter conteinr before
	*
	* @return $html
	*/
	public function site_footer_container_before (){
		
		$html = ' <footer id="colophon" class="site-footer" >';
						
		$html = apply_filters( 'personal_cv_resume_footer_container_before_filter',$html);		
				
		echo wp_kses( $html, $this->alowed_tags() );
		
						
	}
	
	/**
	* Footer Container before
	*
	* @return $html
	*/
	function site_footer_widgets(){
	

        if ( is_active_sidebar( 'footer' ) ) { ?>
         <div id="footer">
         <div class="container">
            <div class="row emart-flex">
                <?php dynamic_sidebar( 'footer' ); ?>
            </div>
         </div>  
         </div>
        <?php }

	}
	
	
	/**
	* diet_shop foter conteinr after
	*
	* @return $html
	*/
	public function site_footer_info (){
		$text ='';
		$html = '<div class="site_info"><div class="container text-center">';
		
			$html .= $this->site_footer_back_top();

			$html .= '<div class="text">';
			
			if( personal_cv_resume_get_option('__copyrights_text') ){

				$text .= esc_html( personal_cv_resume_get_option('__copyrights_text') );

			}elseif( get_theme_mod('copyright_text') != '' ) {

				$text .= esc_html( get_theme_mod('copyright_text') );

			}else{

				/* translators: 1: Current Year, 2: Blog Name  */
				$text .= sprintf( esc_html__( 'Copyright &copy; %1$s %2$s. All Right Reserved.', 'emart-shop' ), date_i18n( _x( 'Y', 'copyright date format', 'emart-shop' ) ), esc_html( get_bloginfo( 'name' ) ) );
				
			}

			$html  .= apply_filters( 'emart_footer_copywrite_filter', $text );
				
		if( !empty( personal_cv_resume_get_option( '_cadires' ) ) ):
			/* translators: 1: developer website, 2: WordPress url  */
			$html  .= '<span class="dev_info">'.sprintf( esc_html__( 'Theme : %1$s By aThemeArt', 'emart-shop' ), '<a href="'. esc_url( 'https://athemeart.com/downloads/emart-multipurpose-woocommerce-theme/' ) .'" target="_blank" rel="nofollow">'.esc_html_x( 'Personal CV Resume', 'credit - theme', 'emart-shop' ).'</a>',  '<a href="'.esc_url( __( 'https://wordpress.org', 'emart-shop' ) ).'" target="_blank" rel="nofollow">'.esc_html_x( 'WordPress', 'credit to cms', 'emart-shop' ).'</a>' ).'</span>';
		endif;

		if( !empty(personal_cv_resume_get_option('social_wrap')) ):
	 	$html .='<ul class="social-profile">';
	 	foreach (personal_cv_resume_get_option('social_wrap') as $row ):
	 		if( !empty($row['icon']) && !empty( $row['link' ]) ){

	 			$css 	= !empty($row['bg'])? 'background:'.esc_attr( $row['bg'] ).'; color:#FFF' : '';
	 			
				$html  .='<li><a href="'.esc_url( $row['link'] ).'" target="_blank" rel="nofollow" style="'.esc_attr( $css ).'"><i class="'.esc_attr($row['icon']).'"></i></a></li>';
	 		}
	 	endforeach;
	 	$html .='</ul>';
	 endif;
			
			$html .= '</div>';
			
		$html .= '</div></div>';
		
		echo wp_kses( $html, $this->alowed_tags() );
	
	}
	
	public function site_footer_back_top (){
		
		$html = '<a id="backToTop" class="ui-to-top active"><i class="icofont-rounded-up parallax"></i></a>';
						
		$html = apply_filters( 'emart_site_footer_back_top_filter',$html);		
				
		return wp_kses( $html, $this->alowed_tags() );
	
	}
	/**
	* diet_shop foter conteinr after
	*
	* @return $html
	*/
	public function site_footer_container_after (){
		
		$html = '</footer>';
						
		$html = apply_filters( 'personal_cv_resume_footer_container_after_filter',$html);		
				
		echo wp_kses( $html, $this->alowed_tags() );
	
	}
	
	
	private function alowed_tags(){
		
		if( function_exists('personal_cv_resume_alowed_tags') ){ 
			return personal_cv_resume_alowed_tags(); 
		}else{
			return array();	
		}
		
	}
}

$personal_cv_resume_footer_layout = new personal_cv_resume_Footer_Layout();