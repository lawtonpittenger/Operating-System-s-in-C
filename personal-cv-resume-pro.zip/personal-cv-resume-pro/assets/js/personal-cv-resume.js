;(function($) {
'use strict'
// Dom Ready
//Trap focus inside mobile menu modal
		//Based on https://codepen.io/eskjondal/pen/zKZyyg	
		var trapFocusInsiders = function(elem) {
			
				
			var tabbable = elem.find('select, input, textarea, button, a').filter(':visible');
			
			var firstTabbable = tabbable.first();
			var lastTabbable = tabbable.last();
			/*set focus on first input*/
			firstTabbable.focus();
			
			/*redirect last tab to first input*/
			lastTabbable.on('keydown', function (e) {
			   if ((e.which === 9 && !e.shiftKey)) {
				   e.preventDefault();
				   
				   firstTabbable.focus();
				  
			   }
			});
			
			/*redirect first shift+tab to last input*/
			firstTabbable.on('keydown', function (e) {
				if ((e.which === 9 && e.shiftKey)) {
					e.preventDefault();
					lastTabbable.focus();
				}
			});
			
			/* allow escape key to close insiders div */
			elem.on('keyup', function(e){
			  if (e.keyCode === 27 ) {
				elem.hide();
			  };
			});
			
		};

		var focus_to = function(action,element) {

			$(action).keyup(function (e) {
			    e.preventDefault();
				var code = e.keyCode || e.which;
				if(code == 13) { 
					$(element).focus();
				}
			});		
			
		}
	$(function() {
		
		if( $('.widget.widget_block h2').length ){
			$('.widget.widget_block h2').each(function() {
  				
  				$(this).html('<span>'+ $(this).text() +'</span>');
			});
		}
		

		if($("#fly-sidebar").length ) {
			$('#sidebar-actions').click

			$("#sidebar-actions").on('click', function(e){
				e.preventDefault();
				$(this).toggleClass('active');
				$("#fly-sidebar").find('.sidewrapper').toggleClass('active');
				
				if ($(this).hasClass("active")) {
					trapFocusInsiders( $('#fly-sidebar') );	
				}else{
					focus_to('#sidebar-actions');
				}
	   		});	

			$('#secondary').slimScroll({
			    height: '100vh'
			});
		}

		/*=============================================
	    =            Main Menu         =
	    =============================================*/

	    
		$('#aside-nav-wrapper .header-wrap.slimScroll').slimScroll({
			height: '100vh'
		});
	   
		$('#navbar .navigation-menu li > a').keyup(function (e) {
			if ( matchMedia( 'only screen and (min-width: 992px)' ).matches ) {
				$("#navbar .navigation-menu li").removeClass('focus');
				$(this).parents('li.menu-item-has-children').addClass('focus').addClass('focus-mode');
			}
		});	

		$('#aside-nav-wrapper').hover(function(){	
			$("li.menu-item-has-children").removeClass('focus-mode');	
		});	

		$("#sidebar-actions-header").on('click', function(e){
			e.preventDefault();
			$(this).toggleClass('active');

			$("#aside-nav-wrapper").toggleClass('active');
			if ($(this).hasClass("active")) {
				trapFocusInsiders( $('#aside-nav-wrapper') );	
			}else{
				focus_to('#sidebar-actions-header');
			}
		});	

		if( $(".masonry_grid").length){
			$('.masonry_grid').masonry({
			  // set itemSelector so .grid-sizer is not used in layout
			  itemSelector: '.grid-item',
			  // use element for option
			  columnWidth: '.grid-sizer',
			  percentPosition: true
			});
		}

		$("a.thickbox").fancybox();
		$("a.fancy_group").fancybox();

		/*----------------------------------------------------
						Counter Function 
		/*----------------------------------------------------*/
        var timer = $('.timer');
        if(timer.length) {
           timer.countTo();
        }

      if( $('.progress-bar').length ){
				$('.progress-bar').each(function(index, value) {
					$(this).css('width', $(this).data('percent') +'%');
					
				});
		  }
/*----------------------------------------------------
						Testimonial SLider
		/*----------------------------------------------------*/
          var tsSlider = $ (".client-slider");
            if(tsSlider.length) {
                tsSlider.owlCarousel({
                  loop:true,
                  nav:true,
                  dots:false,
                  autoplay:true,
                  margin:30,
                  autoplayTimeout:4000,
                  autoplaySpeed:1000,
                  lazyLoad:true,
                  singleItem:true,
                  responsive:{
                      0:{
                          items:1
                      },
                      768:{
                          items:2
                      }
                  }
              });
            }

			/*----------------------------------------------------
						Partner Logo 
		/*----------------------------------------------------*/
        var logoslider = $ (".partner-logo");
          if(logoslider.length) {
			 
              logoslider.owlCarousel({
                loop:true,
                nav:false,
                dots:true,
                autoplay:true,
                autoplayTimeout:4000,
                autoplaySpeed:1000,
                lazyLoad:true,
                singleItem:true,
                responsive:{
                    0:{
                        items:1
                    },
                    550:{
                        items:2
                    },
                    768:{
                        items:3
                    },
                    992:{
                        items:4
                    }
                }
            });
          }
		/*----------------------------------------------------
					Portfolio Gridpcr-portfolio-grid
		/*----------------------------------------------------*/
		if($(".pcr-portfolio-grid").length ) {

		//$('#online-cv-resume-pro-portfolio-grid').mixItUp();
		 	var mixer = mixitup(".pcr-portfolio-grid");
		}

		if( $('#loader-wrapper').length ){
			$('#loader').fadeOut(); // will first fade out the loading animation
			$('#loader-wrapper').delay(350).fadeOut('slow'); // will fade out the white DIV that covers the website.
			$('body').delay(350).css({'overflow':'visible'});
		}

		var tsSlider = $ (".fs-product-slider");
            if(tsSlider.length) {
                tsSlider.owlCarousel({
                  loop:true,
                  nav:false,
                  dots:false,
                  autoplay:true,
                  margin:30,
                  autoplayTimeout:4000,
                  autoplaySpeed:1000,
                  lazyLoad:true,
                  singleItem:true,
                  responsive:{
                      0:{
                          items:1
                      },
                      768:{
                          items:1
                      }
                  }
              });
            }

		/*----------------------------------------------------
							AOS Animation
		/*----------------------------------------------------*/
        AOS.init();

	});
})(jQuery);