<?php
/**
 * Class: Arzot_About_Me_Widgets
 * Name: Arzot About Me
 * Slug: 
 */
namespace Elementor;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Color;
use Elementor\Scheme_Typography;
use Elementor\Widget_Base;
use Elementor\WYSIWYG;
use Elementor\MEDIA;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Arzot_Home_Block_Widgets extends Widget_Base {
	
	public function get_name() {
		return 'arzot-home-block';
	}

	public function get_title() {
		return __( 'Home Page Block', 'personal-cv-resume' );
	}

	public function get_icon() {
		return 'eicon-meta-data arzot-about-me';
	}

	public function get_categories() {
		return [ 'arzot-group' ];
	}
	
	public function get_keywords() {
		return [ 'about me', 'profile', 'about', 'about text' ];
	}
	/**
	 * Register heading widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		
		
		$this->start_controls_section(
			'section_items_general',
			array(
				'label' => esc_html__( 'About Me Content', 'personal-cv-resume' ),
			)
		);
		
		$this->add_control(
			'heading',
			[
				'label' => __( 'Title', 'personal-cv-resume' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => __( 'Heading', 'personal-cv-resume' ),
				'default' => __( 'Jamel Grant', 'personal-cv-resume' ),
				'label_block' => true,
			]
		);
		
		$this->add_control(
			'item_image',
			[
				'label'   => esc_html__( 'Choose Profile', 'personal-cv-resume' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => array(
					'url' => Utils::get_placeholder_image_src(),
				),
			]
		);
		$this->add_control(
			'sub_heading',
			[
				'label' => __( 'Sub Heading', 'personal-cv-resume' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => __( 'Sub Heading', 'personal-cv-resume' ),
				'default' => __( "I'M Professional", 'personal-cv-resume' ),
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'item_title',
			array(
				'label'   => esc_html__( 'Expertise', 'personal-cv-resume' ),
				'label_block' => true,
				'type'    => Controls_Manager::TEXT,
			)
		);
		$this->add_control(
			'item_list',
			array(
				'type'        => Controls_Manager::REPEATER,
				'fields'      => array_values( $repeater->get_controls() ),
				'default'     => array(
					
					array(
						'item_title'     => esc_html__( 'Web Developer', 'personal-cv-resume' ),
					),
					array(
						'item_title'     => esc_html__( 'Photographer', 'personal-cv-resume' ),
					),
					array(
						'item_title'     => esc_html__( 'Engineer', 'personal-cv-resume' ),
					),
					
					
				),
				'title_field' => '{{{ item_title }}}',
			)
		);

		$this->end_controls_section();
		$this->start_controls_section(
			'section_button_group',
			array(
				'label' => esc_html__( 'Button Group', 'personal-cv-resume' ),
			)
		);

		$btn_repeater = new Repeater();
		$btn_repeater->add_control(
			'item_title',
			array(
				'label'   => esc_html__( 'Name', 'personal-cv-resume' ),
				'label_block' => true,
				'type'    => Controls_Manager::TEXT,
			)
		);
		$btn_repeater->add_control(
			'website_link',
			[
				'label' => esc_html__( 'Download Link', 'personal-cv-resume' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'personal-cv-resume' ),
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'label_block' => true,
			]
		);

		$this->add_control(
			'btn_list',
			array(
				'type'        => Controls_Manager::REPEATER,
				'fields'      => array_values( $btn_repeater->get_controls() ),
				'default'     => array(
					
					array(
						'item_title'     => esc_html__( 'Download CV', 'personal-cv-resume' ),
							'website_link'   => array('url' => '#',
							'is_external' => true,
							'nofollow' => true)
					),
					array(
						'item_title'     => esc_html__( 'Hire Me', 'personal-cv-resume' ),
						'website_link'   => array('url' => '#',
							'is_external' => true,
							'nofollow' => true)
					),
					
					
					
				),
				'title_field' => '{{{ item_title }}}',
			)
		);
		$this->end_controls_section();
		

		$this->start_controls_section(
			'section_social_link',
			array(
				'label' => esc_html__( 'Social link', 'personal-cv-resume' ),
			)
		);

		$social = new Repeater();
	
		$social->add_control(
			'item_icon',
			array(
				'label'       => esc_html__( 'Icon', 'personal-cv-resume' ),
				'type'        => Controls_Manager::ICON,
				'label_block' => true,
			)
		);
		$social->add_control(
			'link',
			array(
				'label'   => esc_html__( 'Add Social Link', 'personal-cv-resume' ),
				'type'    => Controls_Manager::TEXT,
			)
		);

		
		$this->add_control(
			'social_list',
			array(
				'type'        => Controls_Manager::REPEATER,
				'fields'      => array_values( $social->get_controls() ),
				'default'     => array(
					array(
						'item_icon'  	=>  esc_attr('fa fa-facebook'),
						'link'  		=> '#' ,
					),
					
					array(
						
						'item_icon'  	=> esc_attr('fa fa-pinterest-p'),
						'link'  		=> '#' ,
					),
					array(
						
						'item_icon'  	=> esc_attr('fa fa-twitter'),
						'link'  		=> '#' ,
					),
					
					
				),
				'title_field' => '{{{ link }}}',
			)
		);

		$this->end_controls_section();
		
		$this->start_controls_section(
            'section-plan-heading-style',
            [
                'label' => __( 'Color', 'personal-cv-resume' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
       );

		$this->add_control(
            'heading_color',
            [
                'label'     => __('Text Color', 'personal-cv-resume'),
                'type'      => Controls_Manager::COLOR,
               
				'default' => '#000',					
                'selectors'    => [
                                '{{WRAPPER}} .homepage-wrap h1.author-name' => 'color: {{VALUE}}',
                                '{{WRAPPER}} .homepage-wrap .cd-headline' => 'color: {{VALUE}}',
                            ]
            ]
		);
		$this->end_controls_section();
	}
	
	/**
	 * Render heading widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		$heading = ( isset( $settings['heading'] ) && $settings['heading'] != "" ) ? esc_html( $settings['heading'] ):'';
		if( !empty( $settings['item_list'] ) ): 
			$data_words = '';
			foreach( $settings['item_list'] as $list ):
				$data_words .= $list['item_title'].',';		
			endforeach;
		endif;	
		?>
		<div class="homepage-wrap">
			<?php if( !empty( $settings['item_image']['url'] ) ) :?>
				<img class="user-img" src="<?php echo esc_url( $settings['item_image']['url'] );?>" alt="<?php echo esc_attr( $heading );?>">
			<?php endif;?>
			<h1 class="author-name"><?php echo esc_html( $heading );?></h1>
			<div class="cd-headline clip is-full-width">
				<span><?php echo esc_html( $settings['sub_heading'] );?></span> <span class="typer" data-colors="<?php echo esc_attr( personal_cv_resume_get_option( '__secondary_color' ) );?>" id="main" data-words="<?php echo esc_attr($data_words);?>" data-delay="100" data-deletedelay="1000"> Pho</span>
			</div>
			<?php if( !empty( $settings['btn_list'] ) ) :
				echo '<div class="btn_group">';
				$link_tags = ''; $i = 0;
				foreach( $settings['btn_list'] as $list ): $i++;
					$css = ( $i % 2 == 0 ) ? 'btn_odd' : '';

					if( !empty($list['website_link']['url']) ):

					$link_tags .= !empty($list['website_link']['url']) ? 'href="'.esc_url($list['website_link']['url']).'"':''; 

					$link_tags .= !empty($list['website_link']['is_external']) ? 'target="_blank"':''; 
					
					$link_tags .= !empty($list['website_link']['nofollow']) ? 'rel="nofollow"':''; 
							
					?>
					<a <?php echo $link_tags;?> class="theme-btn <?php echo esc_attr($css);?>"><span><?php echo esc_html( $list['item_title'] );?></span></a>

			<?php   endif;
				endforeach;
				echo '</div>';
				endif;?>

			<?php if( !empty( $settings['social_list'] ) ) : ?>	
			<div class="social-icon"><ul>
				<?php foreach( $settings['social_list'] as $list ){ ?>
				<li><a href="<?php echo esc_url($list['link']); ?>">
						<i class="<?php echo esc_attr(str_replace("fa ","fab ",$list['item_icon'])); ?>"></i>
					</a></li>

				<?php } ?>
			</ul></div>	
			<?php endif;?>
			
		</div>
		<?php
	}

	
	
}


Plugin::instance()->widgets_manager->register_widget_type( new Arzot_Home_Block_Widgets() );