<?php
/**
 * Class: Arzot_Services_Widgets
 * Name: Arzot Services
 * Slug: 
 */
namespace Elementor;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;
use Elementor\Scheme_Color;
use Elementor\Scheme_Typography;
use Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Arzot_Services_Widgets extends Widget_Base {
	
	public function get_name() {
		return 'arzot-service';
	}

	public function get_title() {
		return __( 'Service Box', 'personal-cv-resume' );
	}

	public function get_icon() {
		return 'eicon-featured-image be-eae-pe';
	}

	public function get_categories() {
		return [ 'arzot-group' ];
	}
	
	public function get_keywords() {
		return [ 'feature', 'service', 'box', 'item' ];
	}
	/**
	 * Register heading widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		
		
		$this->start_controls_section(
			'section_items_data',
			array(
				'label' => esc_html__( 'Service Content', 'personal-cv-resume' ),
			)
		);
		$this->add_control(
			'heading',
			array(
				'label'   => esc_html__( 'Heading', 'personal-cv-resume' ),
				'type'    => Controls_Manager::TEXT,
				'label_block' => true,
				'default' => esc_html__( 'My Services', 'personal-cv-resume' ),
			)
		);
		$repeater = new Repeater();

		$repeater->add_control(
			'item_image',
			array(
				'label'   => esc_html__( 'Hover Background', 'personal-cv-resume' ),
				'type'    => Controls_Manager::MEDIA,
				
			)
		);

		$repeater->add_control(
			'item_icon',
			array(
				'label'       => esc_html__( 'Icon', 'personal-cv-resume' ),
				'type'        => Controls_Manager::ICON,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'item_title',
			array(
				'label'   => esc_html__( 'Title', 'personal-cv-resume' ),
				'type'    => Controls_Manager::TEXT,
				'label_block' => true,
			)
		);

		$repeater->add_control(
			'item_content',
			array(
				'label'   => esc_html__( 'Content', 'personal-cv-resume' ),
				'type'    => Controls_Manager::TEXTAREA,
			)
		);

		
		$this->add_control(
			'item_list',
			array(
				'type'        => Controls_Manager::REPEATER,
				'fields'      => array_values( $repeater->get_controls() ),
				'default'     => array(
					array(
						'item_content'  => esc_html__( 'Lorem Ipsum has been the industry\'s standard dummy text ever since the unknown printer', 'personal-cv-resume' ),
						'item_title'     => esc_html__( 'Professional Code', 'personal-cv-resume' ),
						'item_icon'     => 'fa fa-code',
					),
					array(
						'item_content'  => esc_html__( 'Lorem Ipsum has been the industry\'s standard dummy text ever since the unknown printer', 'personal-cv-resume' ),
						'item_title'     => esc_html__( 'Creative Ideas', 'personal-cv-resume' ),
						'item_icon'     => 'fa fa-lightbulb-o',
					),
					array(
						'item_content'  => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'personal-cv-resume' ),
						'item_title'     => esc_html__( 'User Friendly', 'personal-cv-resume' ),
						'item_icon'     => 'fa fa-heart-o',
					),
					
				),
				'title_field' => '{{{ item_title }}}',
			)
		);

		$this->end_controls_section();
		
		
	
		$this->start_controls_section(
			'columns',
			array(
				'label' => esc_html__( 'Columns', 'personal-cv-resume' ),
			)
		);
		
		$this->add_control(
			'columns_md',
			[
				'label' => __( 'Columns Desktops', 'personal-cv-resume' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'col-md-12' => __( 'Columns 1', 'personal-cv-resume' ),
					'col-md-6' => __( 'Columns 2', 'personal-cv-resume' ),
					'col-md-4' => __( 'Columns 3', 'personal-cv-resume' ),
					'col-md-3' => __( 'Columns 4', 'personal-cv-resume' ),
					
				],
				'default' => 'col-md-6',
			]
		);
		
		$this->add_control(
			'columns_sm',
			[
				'label' => __( 'Columns Tablets', 'personal-cv-resume' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'col-sm-12' => __( 'Columns 1', 'personal-cv-resume' ),
					'col-sm-6' => __( 'Columns 2', 'personal-cv-resume' ),
					'col-sm-4' => __( 'Columns 3', 'personal-cv-resume' ),
					'col-sm-3' => __( 'Columns 1', 'personal-cv-resume' ),
					
				],
				'default' => 'col-sm-6',
			]
		);
		
		$this->add_control(
			'columns_xs',
			[
				'label' => __( 'Columns Phones', 'personal-cv-resume' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'col-12' => __( 'Columns 1', 'personal-cv-resume' ),
					'col-6' => __( 'Columns 2', 'personal-cv-resume' ),
					'col-4' => __( 'Columns 3', 'personal-cv-resume' ),
					'col-3' => __( 'Columns 4', 'personal-cv-resume' ),
					
				],
				'default' => 'col-12',
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'section-box-style',
			[
				'label' => __( 'Box Options', 'personal-cv-resume' ),
				
			]
		);
		
		$this->add_control(
			'box_style',
			[
				'label' => __( 'Box Style', 'personal-cv-resume' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'icon' 	 => 'Icon',
					'number' => 'Number',
				],
				'default' => 'number',
			]
		);
		
		$this->add_control(
			'icon_position',
			[
				'label' => __( 'icon position', 'personal-cv-resume' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'side' 	 => 'Side Heading',
					'top' => 'Top Heading',
				],
				'default' => 'side',
			]
		);
		
		$this->add_control(
            'heading_tag',
            [
                'label' => __( 'Heading HTML Tag', 'personal-cv-resume' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => __( 'H1', 'personal-cv-resume' ),
                    'h2' => __( 'H2', 'personal-cv-resume' ),
                    'h3' => __( 'H3', 'personal-cv-resume' ),
                    'h4' => __( 'H4', 'personal-cv-resume' ),
                    'h5' => __( 'H5', 'personal-cv-resume' ),
                    'h6' => __( 'H6', 'personal-cv-resume' )
                ],
                'default' => 'h4',
            ]
        );
		
		$this->add_control(
            'feature_align',
            [
                'label' => __( 'Alignment', 'wts-eae' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'personal-cv-resume' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'personal-cv-resume' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'personal-cv-resume' ),
						'icon' => 'eicon-text-align-right',
					],
				],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .single-service-block' => 'text-align: {{VALUE}};',
                ]
            ]
        );
		$this->end_controls_section();
		
	
	  $this->start_controls_section(
            'section-plan-heading-style',
            [
                'label' => __( 'Color', 'personal-cv-resume' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
       );

		$this->add_control(
            'heading_color',
            [
                'label'     => __('Heading Color', 'personal-cv-resume'),
                'type'      => Controls_Manager::COLOR,
               
				'default' => '#3a3939',					
                'selectors'    => [
                                '{{WRAPPER}} .single-service-block .pcr-service-loop-heading ' => 'color: {{VALUE}}'
                            ]
            ]
		);
		$this->add_control(
            'heading_icon',
            [
                'label'     => __('Icon Color', 'personal-cv-resume'),
                'type'      => Controls_Manager::COLOR,
               
				'default' => '#1ed373',					
                'selectors'    => [
                                '{{WRAPPER}} .single-service-block .pcr-service-loop-heading  span' => 'color: {{VALUE}}'
                            ]
            ]
		);
		
		$this->add_control(
            'heading_text',
            [
                'label'     => __('Text Color', 'personal-cv-resume'),
                'type'      => Controls_Manager::COLOR,
               
				'default' => '#777777',					
                'selectors'    => [
                                '{{WRAPPER}} .single-service-block .text' => 'color: {{VALUE}}'
                            ]
            ]
		);
		
		$this->end_controls_section();
		
		
		
		
		
		
		
	}
	
	/**
	 * Render heading widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$heading = ( isset( $settings['heading'] ) && $settings['heading'] != "" ) ? esc_html( $settings['heading'] ):'';
	 ?>

        <div class="theme-ribbon-content">
          <div class="my-services mb-80">
            <h4 class="inner-title"><?php echo esc_html( $heading );?></h4>
            <div class="row">
              <?php if( isset( $settings['item_list'] ) && count( $settings['item_list'] ) > 0 ): 
                         $i = 0;
                         foreach( $settings['item_list'] as $list ){ $i++;
                            $bg = '';
                            $text_color = '';	
                            
                        if( isset( $list['item_image'] ) && $list['item_image']['url'] != "" ){
                            $bg = 'background-image: url(\''.esc_url($list['item_image']['url']).'\'); background-position: center bottom; background-size: cover;';
                            $text_color = 'hover-white-text';
                        }	
                        
                         ?>
              <div class="<?php echo esc_attr( $settings['columns_md'] );?> <?php echo esc_attr( $settings['columns_sm'] );?> <?php echo esc_attr( $settings['columns_xs'] );?>" <?php echo _AOS_;?>>
                <div class="single-service-block shadow-box  <?php echo esc_attr( $text_color );?> " style=" <?php echo esc_attr( $bg );?> ">
                  <<?php echo $settings['heading_tag'];?> class="pcr-service-loop-heading"> <span class="<?php echo esc_attr( $settings['icon_position'] );?>">
                    <?php 
                            if( $settings['box_style'] == 'number' ) {
                                echo sprintf("%02d",$i);
                            }else{
                                echo  '<i aria-hidden="true" class="'.esc_attr( $list['item_icon'] ).'"></i>' ;
                            }
                         ?>
                    </span> <?php echo isset( $list['item_title'] ) ? esc_html( $list['item_title'] ) : ''; ?> </<?php echo $settings['heading_tag'];?>>
                  <div class="text"><?php echo esc_html( $list['item_content'] );?></div>
                </div>
                <!-- /.single-service-block --> 
              </div>
              <?php }?>
              <?php endif;?>
            </div>
          </div>
          <!-- /.row --> 
          <div class="clearfix"></div>
        </div>
      
        
<?php 
	}

	/**
	 * Render heading widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() {
	?>
       <div class="theme-ribbon-content">
        <div class="my-services mb-80">
          <h4 class="inner-title">{{{settings.heading}}}</h4>
          <div class="row"> 
			<#  var i = 0;
            _.each( settings.item_list, function( list, index ) { i++; 
            #>
            <div class="{{{settings.columns_md}}} {{{settings.columns_sm}}} {{{settings.columns_xs}}}">
				<# if( list.item_image.url != '') { #>
			  		<div class="single-service-block shadow-box hover-white-text" 
				  		style= "background-image: url( {{{list.item_image.url}}} ); background-position: center bottom; background-size: cover;"> 
				<# } else { #>
                <div class="single-service-block shadow-box" > 
					<# } #>
					<{{{settings.heading_tag}}} class="pcr-service-loop-heading"> 
					
						<span class="{{{settings.icon_position}}}"> 
							<# if( settings.box_style == 'number') {#>
							{{{ i }}}
							<# } else { #> <i aria-hidden="true" class="fa {{{list.item_icon}}}"></i> <# } #> 
						</span> 
						{{{list.item_title}}} 

					</{{{settings.heading_tag}}}>

				  <div class="text">{{{list.item_content}}} </div>
				  
                </div>
                <!-- /.single-service-block --> 
              </div>
            <# }); #> 
          </div>
          <div class="clearfix"></div>
        </div>
<?php	
	}
	
}


Plugin::instance()->widgets_manager->register_widget_type( new Arzot_Services_Widgets() );
