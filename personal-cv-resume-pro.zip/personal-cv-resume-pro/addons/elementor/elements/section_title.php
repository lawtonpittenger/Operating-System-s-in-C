<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class aThemeArt_Heading_Widgets extends Widget_Base {
	
	public function get_name() {
		return 'ata-heading';
	}

	public function get_title() {
		return __( 'Section Title', 'personal-cv-resume' );
	}

	public function get_icon() {
		return 'eicon-heading ata-eae-pe';
	}

	public function get_categories() {
		return ['arzot-group'];
	}
	
	public function get_keywords() {
		return [ 'heading', 'title', 'text', 'section Header' ];
	}
	/**
	 * Register heading widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'section_title',
			[
				'label' => __( 'Title', 'personal-cv-resume' ),
			]
		);

		$this->add_control(
			'title',
			[
				'label' => __( 'Title', 'personal-cv-resume' ),
				'type' => Controls_Manager::TEXTAREA,
				
				'placeholder' => __( 'Enter your title', 'personal-cv-resume' ),
				'default' => __( 'Add Your Heading Text Here', 'personal-cv-resume' ),
			]
		);
		$this->add_control(
			'heading_top',
			[
				'label' => __( 'Heading Top ', 'personal-cv-resume' ),
				'type' => Controls_Manager::TEXT,
				'label_block' =>true,
			]
		);
	
		
		
		$this->add_control(
			'be_description',
			[
				'label' => __( 'Heading Description', 'personal-cv-resume' ),
				'type' => Controls_Manager::TEXTAREA,
				
				'placeholder' => __( 'Enter Heading Description', 'personal-cv-resume' ),
				'default' => __( 'We are digital thinkers', 'personal-cv-resume' ),
			]
		);
		
		$this->add_control(
			'shadow',
			[
				'label' => __( 'Heading End Or Shadow ', 'personal-cv-resume' ),
				'type' => Controls_Manager::TEXT,
				
				'placeholder' => __( 'Enter Shadow Text', 'personal-cv-resume' ),
				'default' => __( '.....', 'personal-cv-resume' ),
				'label_block' =>true,
			]
		);
		$this->add_control(
			'heading_style',
			[
				'label' => __( 'Heading Style', 'personal-cv-resume' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'ata_heading_style_1' => __( 'Style - 1', 'personal-cv-resume' ),
					'ata_heading_style_2' => __( 'Style - 2', 'personal-cv-resume' ),
					'ata_heading_style_3' => __( 'Style - 3', 'personal-cv-resume' ),
				],
				'default' => 'ata_heading_style_1',
			]
		);
		
		$this->end_controls_section();
		$this->start_controls_section(
			'section_heading_tag',
			[
				'label' => __( 'HTML Tag', 'personal-cv-resume' ),
				 'tab' => Controls_Manager::TAB_STYLE
				
			]
		);
		$this->add_control(
			'heading_size',
			[
				'label' => __( 'Heading Style', 'personal-cv-resume' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'default' =>  __( 'Default', 'personal-cv-resume' ),
					'display-5' =>  __( 'Small', 'personal-cv-resume' ),
					'display-4' =>  __( 'Medium', 'personal-cv-resume' ),
					'display-3' =>  __( 'Large', 'personal-cv-resume' ),
					'display-2' =>  __( 'XL', 'personal-cv-resume' ),
					'display-1' =>  __( 'XXL', 'personal-cv-resume' ),
				],
				'default' => 'default',
			]
		);
		$this->add_control(
			'header_tag',
			[
				'label' => __( 'Heading Tags', 'personal-cv-resume' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p',
				],
				'default' => 'h2',
			]
		);
		$this->add_control(
			'font-weight',
			[
				'label' => __( 'Heading Weight', 'personal-cv-resume' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'normal' => [
						'title' => __( 'Normal', 'personal-cv-resume' ),
						'icon' => 'fa fa-font',
					],
					'bold' => [
						'title' => __( 'Bold', 'personal-cv-resume' ),
						'icon' => 'fa fa-bold',
					],
				],
				'default' => 'bold',
				'selectors' => [
					 '{{WRAPPER}} .be-heading' => 'font-weight: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
				'space_up',
				[
					'label' => __( 'Heading up space ', 'personal-cv-resume' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'devices' => [ 'desktop', 'tablet', 'mobile' ],
					'desktop_default' => [
						'size' => 10,
						'unit' => 'px',
					],
					'tablet_default' => [
						'size' => 5,
						'unit' => 'px',
					],
					'mobile_default' => [
						'size' => 5,
						'unit' => 'px',
					],
					'selectors' => [
						'{{WRAPPER}} .fs-subheading' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					],
				]
			);
		$this->add_responsive_control(
				'space_between',
				[
					'label' => __( 'Heading below space ', 'personal-cv-resume' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'devices' => [ 'desktop', 'tablet', 'mobile' ],
					'desktop_default' => [
						'size' => 15,
						'unit' => 'px',
					],
					'tablet_default' => [
						'size' => 10,
						'unit' => 'px',
					],
					'mobile_default' => [
						'size' => 10,
						'unit' => 'px',
					],
					'selectors' => [
						'{{WRAPPER}} .be-heading' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					],
				]
			);
				
		$this->add_control(
			'align',
			[
				'label' => __( 'Alignment', 'personal-cv-resume' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'personal-cv-resume' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'personal-cv-resume' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'personal-cv-resume' ),
						'icon' => 'fa fa-align-right',
					],
					'justify' => [
						'title' => __( 'Justified', 'elementor' ),
						'icon' => 'fa fa-align-justify',
					],
				],
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}}' => 'text-align: {{VALUE}};',
				],
			]
		);

		

		$this->end_controls_section();
		
		
		
		
	}
	
	/**
	 * Render heading widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( empty( $settings['title'] ) ) {
			return;
		}

		$this->add_render_attribute( 'base_warpper', 'class', 'ata-section-title ' );
		$this->add_render_attribute( 'base_warpper', 'class', esc_attr( $settings['heading_style'] ) );
	
		
		$heading_text = ( $settings['heading_style'] == 'ata_heading_style_1' ) ? $this->ata_text_spirit( $settings['title'], $settings['shadow']) : $settings['title'];
		
		if( $settings['heading_style'] == 'ata_heading_style_1' ){
			$heading_text = $this->ata_text_spirit( $settings['title'], $settings['shadow']);
		}else if( $settings['heading_style'] == 'ata_heading_style_3' ){
			$heading_text = $this->ata_style3_spirit( $settings['title'], $settings['shadow'] );
		}else{
			$heading_text = $settings['title'];
		}
		
		$be_heading_html =sprintf(
			'<div %1$s '._AOS_.'>
			<strong class="fs-subheading">%2$s</strong>
            <%3$s class="be-heading %4$s" data-bigletter="%5$s">%6$s</%3$s>
            <div class="be_description">%7$s</div>
          	</div>',
			$this->get_render_attribute_string( 'base_warpper' ),
			$settings['heading_top'],
			$settings['header_tag'],
			esc_html( $settings['heading_size'] ),
			esc_html( $settings['shadow'] ),
			wp_kses_post ( $heading_text ),
			wp_kses_post( $settings['be_description'] )
			
		);
		echo $be_heading_html;
	}

	/**
	 * Render heading widget output in the editor.
	 *
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function content_template() {
		?>
        <# if( settings.heading_style == 'ata_heading_style_1') { #>
         	<#
            var be_heading_html = '<div class="ata-section-title ' + settings.heading_style + '"><strong>' + settings.heading_top + '</strong><' + settings.header_tag + ' class="be-heading ' + settings.heading_size + '">' + settings.title + settings.shadow + '</' + settings.header_tag + '> <div class="be_description">' + settings.be_description + '</div></div>';
            print( be_heading_html );
            #>
        <# }else{ #>
            <#
            var be_heading_html = '<div class="ata-section-title ' + settings.heading_style + '"><strong>' + settings.heading_top + '</strong><' + settings.header_tag + ' class="be-heading ' + settings.heading_size + '" data-bigletter="' + settings.shadow + '">' + settings.title + '</' + settings.header_tag + '> <div class="be_description">' + settings.be_description + '</div></div>';
            print( be_heading_html );
            #>
        <# } #>    
		<?php
	}
	private function ata_text_spirit( $text , $end ){
		$text = trim($text);
		$array = explode( ' ' , $text );
		$counter = count( $array );
		if($counter > 1){
		$last_word = array_pop( $array );
		unset( $array[ $counter ] );
		return implode(' ', $array) . ' <span class="theme-color">'. $last_word.''.$end. '</span>';
		}else{
			return $text;
		}
	}
	
	private function ata_style3_spirit( $text , $end ){
		$text = trim($text);
		$array = explode( ' ' , $text );
		if( count( $array ) > 1 ){
			$span = '<span class="slim-text">'.$array[0].'</span>';
			unset( $array[0] );
			return $span.' '.implode(' ', $array);
		}else{
			return $text;
		}
		
	
	}
	
}




add_action( 'elementor/widgets/widgets_registered', function ( $widgets_manager ) {
$widgets_manager->register_widget_type( new aThemeArt_Heading_Widgets() );
} );
