<?php
namespace Elementor;
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
	add_action( 'elementor/elements/categories_registered', function () {
		
		$elementsManager = Plugin::instance()->elements_manager;
		
		$elementsManager->add_category(
			'arzot-group',
			array(
				'title' => 'Personal CV Resume',
				'icon'  => 'fonts',
			)
		);
	} );


// function that runs when shortcode is called


