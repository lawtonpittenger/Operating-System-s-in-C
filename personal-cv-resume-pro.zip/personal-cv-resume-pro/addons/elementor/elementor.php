<?php

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die();
}

// If class `Jet_Elements` doesn't exists yet.
if ( ! class_exists( 'aThemeArt_WooCommerce_Elementor_Addons' ) ) {
	
	 /**
	 * Sets up and initializes the plugin.
	 */
final class aThemeArt_WooCommerce_Elementor_Addons {
		/**
		 * A reference to an instance of this class.
		 *
		 * @since  1.0.0
		 * @access private
		 * @var    object
		 */
		private static $instance = null;

		/**
		 * A reference to an instance of cherry framework core class.
		 *
		 * @since  1.0.0
		 * @access private
		 * @var    object
		 */
		private $core = null;

		/**
		 * Holder for base plugin URL
		 *
		 * @since  1.0.0
		 * @access private
		 * @var    string
		 */
		private $plugin_url = null;

		/**
		 * Plugin version
		 *
		 * @var string
		 */

		private $version = '1.0.0';

		/**
		 * Holder for base plugin path
		 *
		 * @since  1.0.0
		 * @access private
		 * @var    string
		 */
		private $plugin_path = null;

		/**
		 * Sets up needed actions/filters for the plugin to initialize.
		 *
		 * @since 1.0.0
		 * @access public
		 * @return void
		 */
		public function __construct() {

			// Load the core functions/classes required by the rest of the plugin.
			add_action( 'after_setup_theme', array( $this, 'get_core' ), 1 );
			

			// Load files.
			add_action( 'init', array( $this, 'init' ), -999 );
			
			add_action( 'wp_enqueue_scripts', array( $this, 'wp_enqueue' ),999 );
			
			add_action('elementor/widgets/widgets_registered', array( $this, 'widgets_registered' ), 1);
			
			add_action( 'elementor/editor/after_enqueue_styles', array(  $this, 'elementor_enqueue' ) );
			add_action( 'elementor/frontend/after_enqueue_styles',  array(  $this, 'elementor_enqueue' ) );

		}

		/**
		 * Loads the core functions. These files are needed before loading anything else in the
		 * plugin because they have required functions for use.
		 *
		 * @since  1.0.0
		 * @access public
		 * @return object
		 */
		public function get_core() {

			
		}

		/**
		 * Returns plugin version
		 *
		 * @return string
		 */
		public function get_version() {
			return $this->version;
		}

		/**
		 * Manually init required modules.
		 *
		 * @return void
		 */
		public function init() {
			
			$this->load_files();
			

		}
		public function widgets_registered(){
			
			require $this->plugin_path('elements/section_title.php');
			require $this->plugin_path('elements/arzot-home.php');
			
			require $this->plugin_path('elements/arzot-about-me.php');
			require $this->plugin_path('elements/arzot-service.php');
			require $this->plugin_path('elements/arzot-counter.php');
		    require $this->plugin_path('elements/arzot-price.php');
			require $this->plugin_path('elements/arzot-testimonials.php');
			require $this->plugin_path('elements/arzot-clients-logo.php');
			require $this->plugin_path('elements/arzot-achievement.php');
			require $this->plugin_path('elements/arzot-time-line.php');
			require $this->plugin_path('elements/arzot-progress-bar.php');
			require $this->plugin_path('elements/arzot-project-portfolio.php');
			require $this->plugin_path('elements/arzot-social-link.php');
			
		}
		/**
		 * Check if theme has elementor
		 *
		 * @return boolean
		 */
		public function has_elementor() {
			return defined( 'ELEMENTOR_VERSION' );
		}

		/**
		 * [elementor description]
		 * @return [type] [description]
		 */
		public function elementor() {
			return \Elementor\Plugin::$instance;
		}

		/**
		 * Returns utility instance
		 *
		 * @return object
		 */
		public function utility() {
		
		}

		/**
		 * Load required files.
		 *
		 * @return void
		 */
		public function load_files() {
			require $this->plugin_path( 'includes/elementor-helper.php' );
			
		}

		/**
		 * Returns path to file or dir inside plugin folder
		 *
		 * @param  string $path Path inside plugin dir.
		 * @return string
		 */
		public function plugin_path( $path = null ) {

			if ( ! $this->plugin_path ) {

				$this->plugin_path = trailingslashit( get_template_directory().'/addons/elementor/' );
				
				//$this->plugin_path = plugin_dir_path(__FILE__ ).'/';
			}

			return $this->plugin_path . $path;
		}
		/**
		 * Returns url to file or dir inside plugin folder
		 *
		 * @param  string $path Path inside plugin dir.
		 * @return string
		 */
		public function plugin_url( $path = null ) {

			if ( ! $this->plugin_url ) {
				$this->plugin_url = trailingslashit( get_theme_file_uri() .'/addons/elementor/' );
			}

			return $this->plugin_url . $path;
		}

		

		/**
		 * Get the template path.
		 *
		 * @return string
		 */
		public function template_path() {
			return apply_filters( 'addons/elementor', 'athemeart-elements-addon/' );
		}

		/**
		 * Returns path to template file.
		 *
		 * @return string|bool
		 */
		public function get_template( $name = null ) {

			$template = locate_template( $this->template_path() . $name );

			if ( ! $template ) {
				$template = $this->plugin_path( 'templates/' . $name );
			}

			if ( file_exists( $template ) ) {
				return $template;
			} else {
				return false;
			}
		}


		/**
		 * Load  enqueue script & Style
		 *
		 * @return void
		 */
		public function wp_enqueue() {
			if( !is_admin() ){
				//wp_enqueue_script( 'diet-shop-elements-addon', $this->plugin_url( 'assets/be-elements-addon.js' ), 0, '1.0', true );
				wp_enqueue_style( 'athemeart-elements-addon', $this->plugin_url( 'assets/elements.css' ), '1.0.0' );
			}
			
			
		}
		
		public function elementor_enqueue(){
			
		}
		


		/**
		 * Do some stuff on plugin activation
		 *
		 * @since  1.0.0
		 * @return void
		 */
		public function activation() {
		}

		/**
		 * Do some stuff on plugin activation
		 *
		 * @since  1.0.0
		 * @return void
		 */
		public function deactivation() {
		}

		/**
		 * Returns the instance.
		 *
		 * @since  1.0.0
		 * @access public
		 * @return object
		 */
		public static function get_instance() {
			// If the single instance hasn't been set, set it now.
			if ( null == self::$instance ) {
				self::$instance = new self;
			}
			return self::$instance;
		}

	}
}

if ( ! function_exists( 'athemeart_elements' ) ) {

	/**
	 * Returns instanse of the plugin class.
	 *
	 * @since  1.0.0
	 * @return object
	 */
	function athemeart_elements() {
		return aThemeArt_WooCommerce_Elementor_Addons::get_instance();
	}
	athemeart_elements();
}

//add_action( 'plugins_loaded', 'athemeart_elements' );


