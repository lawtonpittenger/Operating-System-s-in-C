<?php 
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
/*-----------------Section Title------------------------*/
add_shortcode( 'bartag', 'pcr_section_title_func' );
function pcr_section_title_func( $atts ) {
    $atts = shortcode_atts( array(
        'class' => 'ata-section-title ata_heading_style_2',
        'top_text' => '',
        'header_tag' => 'h2',
        
    ), $atts );
 

    //return "foo = {$atts['foo']}";
}

add_action( 'init', 'arzot_toolkit_custom_post' );

if( !function_exists('arzot_toolkit_custom_post') ):
    function arzot_toolkit_custom_post() {
        
        
        register_post_type( 'project',
            array(
                'labels' => array(
                    'name' => esc_html__( 'Projects', 'Post Type General Name', 'arzot-elements-addon' ),
                    'singular_name' => esc_html__( 'Project', 'Post Type Singular Name', 'arzot-elements-addon' )
                ),
                'supports' => array('title', 'editor', 'thumbnail', 'page-attributes'),
                'menu_icon'   => 'dashicons-portfolio',
                'public' => true,
            )
        );
    
    }
endif;

if( !function_exists('arzot_toolkit_custom_post_taxonomy') ):
    function arzot_toolkit_custom_post_taxonomy() {
        register_taxonomy(
            'projects_cat',
            'project',                  
            array(
                'hierarchical'          => true,
                'label'                 => esc_html__( 'Project Category', 'arzot-elements-addon' ),  
                'query_var'             => true,
                'show_admin_column'     => true,
                'rewrite'               => array(
                    'slug'              => 'project-category', 
                    'with_front'    => true 
                    )
                )
        );
    }
    add_action( 'init', 'arzot_toolkit_custom_post_taxonomy');

endif;
