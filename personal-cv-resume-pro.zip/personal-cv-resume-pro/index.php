<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Personal_CV_Resume
 */

get_header();

$layout = personal_cv_resume_get_option('__blog_layout');

/**
* Hook - personal_cv_resume_container_wrap_start 	
*
* @hooked personal_cv_resume_container_wrap_start	- 5
*/
 do_action( 'personal_cv_resume_container_wrap_start',  esc_attr( $layout ) );
 
	if ( have_posts() ) :

		if ( is_home() && ! is_front_page() ) :
			?>
			<header>
				<h1 class="page-title screen-reader-text"><?php single_post_title(); ?></h1>
			</header>
			<?php
		endif;
		
		$post_layout = personal_cv_resume_get_option('__blog_template_layout');
		if( $post_layout == 'grids' ){
			echo '<div class="row">';	
		}else if( $post_layout == 'masonry' ){
			$column_desk    = personal_cv_resume_get_option('__blog_loop_desk');
			$column_tab     = personal_cv_resume_get_option('__blog_loop_tab');
			$column_pho     = personal_cv_resume_get_option('__blog_loop_pho');
			echo '<div class="masonry_grid row">
			       <div class="grid-sizer '.esc_attr($column_desk).' '.esc_attr($column_tab).' '.esc_attr($column_pho).'blog-margin-top grid_layout"></div>';
		}
		/* Start the Loop */
		while ( have_posts() ) :
			the_post();

			/*
			 * Include the Post-Type-specific template for the content.
			 * If you want to override this in a child theme, then include a file
			 * called content-___.php (where ___ is the Post Type name) and that will be used instead.
			 */
			get_template_part( 'template-parts/content', esc_attr($post_layout) );

		endwhile;
		if( $post_layout == 'grids' ){
			echo '</div>';	
		}else if( $post_layout == 'masonry' ){
			echo '</div></div>';
		}
		/**
		* Hook - personal_cv_resume_loop_navigation 	
		*
		* @hooked site_loop_navigation	- 10
		*/
		 do_action( 'personal_cv_resume_loop_navigation');

	else :

		get_template_part( 'template-parts/content', 'none' );

	endif;
		
/**
* Hook - personal_cv_resume_container_wrap_end	
*
* @hooked container_wrap_end - 999
*/
 do_action( 'personal_cv_resume_container_wrap_end',  esc_attr( $layout ) );
get_footer();