<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}
/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/theme-core.php';


/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

require get_template_directory() . '/inc/theme-options.php';

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/class/class-header.php';

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/class/class-body.php';

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/class/class-footer.php';

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/class/class-template-tags.php';
require get_template_directory() . '/class/class-post-related.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
    require get_template_directory() . '/inc/jetpack.php';
}

/**
* TGM Plugins
*/
require get_template_directory() . '/inc/tgm/recommended-plugins.php';

require get_template_directory() . '/addons/shortcode.php';

require get_template_directory() . '/addons/elementor/elementor.php';

defined( 'ATA_PRODUCT_SLUG' )  or  define( 'ATA_PRODUCT_SLUG','personal-cv-resume-pro' );
defined( 'ATA_PRODUCT_LICENSE_SERVER_URL' )  or  define( 'ATA_PRODUCT_LICENSE_SERVER_URL','https://athemeart.com/api/');
defined( 'ATA_PRODUCT_URL' )  or  define( 'ATA_PRODUCT_URL','https://athemeart.com/api/');

require get_template_directory().'/theme-updates/plugin-update-checker.php';

function fs_update_checker(){
   $get_lc     =  !empty( get_option( 'atheme_license_info' ) ) ? maybe_unserialize( get_option( 'atheme_license_info' ) ) : '';       
   
   if( !empty( $get_lc['token'] ) && !empty( $get_lc['license_key'] ) ):
   
      $api_params = array(
         'update_slug'       => ATA_PRODUCT_SLUG,
         'token'    => esc_attr( $get_lc['token'] ),
         'license_key' => esc_attr( $get_lc['license_key'] ),
      );
      
      $query = esc_url_raw(add_query_arg( $api_params, ATA_PRODUCT_LICENSE_SERVER_URL));
      
      if( !empty( $query ) ){
      $myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
         esc_url_raw($query),
         __FILE__,
         ATA_PRODUCT_SLUG
      );
      }
   endif;
}
add_action( 'init', 'fs_update_checker' );

delete_option( 'atheme_license_info' );