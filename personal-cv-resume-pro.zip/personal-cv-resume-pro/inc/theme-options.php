<?php
/**
 * Diet Theme Options
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Diet_Shop
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

add_filter( 'csf_welcome_page', '__return_false' );


require get_template_directory() . '/inc/default.php';

if( class_exists('CSF') ):

require get_template_directory() . '/inc/options/widgets.php';

require get_template_directory() . '/inc/options/nav-options.php';
	
  // Set a unique slug-like ID
  $prefix 					= '__pcr_options';
  $shoper_default 	= function_exists('personal_cv_resume_default_options') ? personal_cv_resume_default_options() : '';
  $personal_cv_resume_default 	= function_exists('personal_cv_resume_default_options') ? personal_cv_resume_default_options() : '';
  
  //
  // Create options
  CSF::createOptions( $prefix, array(
		'framework_title'    => 'Theme Options',
		'menu_title' 		 => 'Theme Options',
		'menu_slug'  		 => 'pcr-options',
		'menu_position'  	 => '1',
		'menu_icon'  		 => 'dashicons-admin-appearance',
  ) );



  require get_template_directory() . '/inc/options/general_settings.php';
  require get_template_directory() . '/inc/options/sidebarnav.php';
  
  require get_template_directory() . '/inc/options/styling-options.php';
  require get_template_directory() . '/inc/options/page-layout.php';
  require get_template_directory() . '/inc/options/blog-options.php';

  require get_template_directory() . '/inc/options/footer.php';
 
   require get_template_directory() . '/inc/options/localization.php';
	

  // Create a section
  CSF::createSection( $prefix, array(
		'title'  => 'Backup',
		'icon'	 => 'cs-icon fa fa-shield',
		'fields' => array(

			// A textarea field
			array(
				'type'  => 'backup',
			),

    )

  ));


 //
//add_filter( 'csf_welcome_page', '__return_false' );
endif;


if ( ! function_exists( 'personal_cv_resume_get_option' ) )  {
	
	  function personal_cv_resume_get_option( $option_name = '' ) {
		
		$default = personal_cv_resume_default_options();
	
		$default_value = ! empty( $default[$option_name] ) ? $default[$option_name] : null;
		
		if( class_exists( 'CSF' ) ) :
			
			$options = apply_filters( 'personal_cv_resume_options_filters', get_option('__pcr_options') );
			
			if( ! empty( $options ) && isset( $options ) ){
			
			  return isset( $options[$option_name] ) ? $options[$option_name] : $default_value;
			  
			} else {
			  
			  return $default_value;
			  
			}
		else:
		
			if(  isset( $default[$option_name] ) ) 
			{
				return ( ! empty( $default[$option_name] ) ) ? $default[$option_name] : null;
			}
		endif;
		
		
	  }
	
}




require get_template_directory() . '/inc/options/meta-options.php';

if ( ! defined( '_AOS_' ) ) {
	// Replace the version number of the theme on each release.
	//define( '_AOS_', 'data-aos="fade-up"' );
	
	$aos = !empty( personal_cv_resume_get_option( '__page_aos' ) ) ? 'data-aos="fade-up"' : '';
	define( '_AOS_', $aos );
}
