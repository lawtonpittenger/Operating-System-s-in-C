<?php


if ( ! function_exists( 'personal_cv_resume_default_options' ) ) :

	/**
	 * Get default theme options
	 *
	 * @since 1.0.0
	 *
	 * @return array Default theme options.
	 */
	function personal_cv_resume_default_options() {

		$defaults		 					= array();
		$defaults['__site_title_n_tagline']	= true;
		$defaults['__sidebar_slimscroll']	= true;
		
		$defaults['__navbar_link_color']    = array(
												'color' => '#3a3939',
												'hover' => '#1ed373',
											);	
		
		$defaults['__navbar_typography'] 	= array(
												'font-family'  => 'K2D',
												'font-weight'  => '500',
												'text-transform' => 'Uppercase',
												'font-size'    => '16',
												'letter-spacing'=> '0',
												'type'         => 'google',
											 );	
		$defaults['social_profile']			= array(
			array(
				'icon' => 'fab fa-facebook-f',
				'link' => '#',
				'bg' => '#3b5998',
			),
			array(
				'icon' =>'fab fa-twitter',
				'link' =>'#',
				'bg' => '#00acee',
			),
			array(
				'icon' =>'fab fa-youtube',
				'link' =>'#',
				'bg' => '#dd3333',
			)
		);

		/* ------------------------------------------------------------------*/
		/*-----------------------Styling Options--------------------------*/
		/* ------------------------------------------------------------------*/

		$defaults['__primary_color']	= '#777777';
		$defaults['__secondary_color']	= '#1ed373';
		$defaults['__tertiary_color']	= '#000';
		$defaults['__quaternary_color']	= '#fff';

		/* ------------------------------------------------------------------*/
		/*-----------------------Styling Options--------------------------*/
		/* ------------------------------------------------------------------*/
		$defaults['__page_layout']		= 'full-container';
		$defaults['__custom_404_page']	= false;
		
		/* ------------------------------------------------------------------*/
		/*-----------------------Blog--------------------------*/
		/* ------------------------------------------------------------------*/
		
		$defaults['__blog_layout']				= 'full-container';
		$defaults['__blog_template_layout']		= 'standard';
		$defaults['__blog_meta']				= array('author','date','category');
		$defaults['__blog_loop_desk']			= 'col-md-6';
		$defaults['__blog_loop_tab']			= 'col-sm-6';
		$defaults['__blog_loop_pho']			= 'col-12';
		$defaults['__archive_heading']			= 'h3';
		$defaults['__readmore_text']			= esc_html__('Read More', 'personal-cv-resume');

		/*----------------------- Single --------------------------*/

		$defaults['__single_layout']			= 'full-container';
		$defaults['__single_post_meta']			= array('author','date','category','tag');
		$defaults['__single_post_featured']		= true;
		$defaults['__posts_share']				= true;
		$defaults['__single_post_nav']			= true;

		/*----------------------- Single --------------------------*/

		$defaults['__footer_bg']				= '';
		$defaults['__footer_columns_md']		= 'col-md-6';
		$defaults['__footer_columns_sm']		= 'col-sm-4';
		$defaults['__footer_columns']			= 'col-12';
		$defaults['__footer_link']				=  array(
													'color' => '#000',
													'hover' => '#1ed373',
												);
		$defaults['__copyrights_text']			= 'col-12';
		$defaults['_cadires']					= true;

		$defaults['__page_loading']				= false;
		$defaults['__page_aos']					= true;
		$defaults['__fly_sidebar']				= true;

		$defaults['social_wrap']				= array();

		$defaults['__blog_content']				= 'excerpt';
		$defaults['__blog_pagination']			= 'numeric';
		$defaults['__single_post_author']		= false;
		
		$defaults['_copyrights_text']			= __('Copyright © 2026 Personal CV Resume. All Right Reserved.','personal-cv-resume');
 

		$defaults['__pcr_by_text']			= esc_html__( 'By -','personal-cv-resume' );
		$defaults['__pcr_posted_on']			= esc_html__( 'Posted on','personal-cv-resume' );
		$defaults['__pcr_posted_in']			= esc_html__( 'Posted in','personal-cv-resume' );
		$defaults['__pcr_tags_text']			= esc_html__( 'Tags','personal-cv-resume' );
		$defaults['__pcr_share_this']			= esc_html__( 'Share this','personal-cv-resume' );

		$defaults['__readmore_text']			= esc_html__( 'Read More','personal-cv-resume' );
		$defaults['__pcr_previous_article']		= esc_html__( 'Previous Article','personal-cv-resume' );
		$defaults['__pcr_next_article']			= esc_html__( 'Next Article','personal-cv-resume' );

		$defaults['__pcr_name_text']			= esc_html__( 'Your Name','personal-cv-resume' );
		$defaults['__pcr_email_text']			= esc_html__( 'Your Email','personal-cv-resume' );
		$defaults['__pcr_website_text']			= esc_html__( 'Website','personal-cv-resume' );
		$defaults['__pcr_save_text']			= esc_html__( 'Save my name, email, and website in this browser for the next time I comment.','personal-cv-resume' );
		$defaults['__pcr_comment_text']			= esc_html__( 'Comment','personal-cv-resume' );
		$defaults['__pcr_post_comment']			= esc_html__( 'Post Comment','personal-cv-resume' );
		
		  		// Pass through filter.
		$defaults 		 					= apply_filters( 'personal_cv_resume_default_options', $defaults );
		
		return $defaults;

	}

endif;