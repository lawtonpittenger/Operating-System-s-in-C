<?php

if ( ! defined( 'ABSPATH' ) ) {
exit; // Exit if accessed directly.
}
// Create a section
CSF::createSection( $prefix, array(
	'icon'      => 'fa fa-newspaper-o',
	'id'    		=> 'page-settings',
	'title'  		=> __('Page Settings','personal-cv-resume'),
	
	
));


// Create a section
CSF::createSection( $prefix, array(
	'parent'        => 'page-settings',
	'icon'      => 'fa fa-cogs',
	'id'    		=> 'page_layout',
	'title'  		=> __('Page','personal-cv-resume'),
	'description' 	=>  __('This contains common setting options which will be applied to the whole site page.','personal-cv-resume'),
	'fields' => array(
	
		array(
				'id'             => '__page_layout',
				'type'           => 'select',
				'title'          => esc_html__('Page Layout ','personal-cv-resume'),
				'default'        => $personal_cv_resume_default['__page_layout'],
				'options'        => array(
					'sidebar-content'  => esc_html__( 'Primary Sidebar / Content', 'personal-cv-resume' ),
					'right-sidebar' => esc_html__( 'Content / Primary Sidebar', 'personal-cv-resume' ),
					'full-container'    => esc_html__( 'No Sidebar', 'personal-cv-resume' ),
				),
				'subtitle'    => __('The options create your theme\'s page layout.','personal-cv-resume'),
			),
			
	)
));


// Create a section
CSF::createSection( $prefix, array(
	'parent'        => 'page-settings',
	'icon'      => 'fa fa-cogs',
	'id'    		=> 'page_404_layout',
	'title'  		=> __('404 Page','personal-cv-resume'),
	'description' 	=>  __('This contains common setting options which will be applied to the whole site page.','personal-cv-resume'),
	'fields' => array(
		
		array(
		  'id'      => '__custom_404_page',
		  'type'    => 'switcher',
		  'title'   => 'Custom 404 page ?',
		  'default' => true,
		  'default'    => esc_url( $personal_cv_resume_default['__custom_404_page'] ) 
		),
		//Text To Display
		array(
		  'id'          => '__custom_404_page_id',
		  'type'        => 'select',
		  'title'       => 'Select Custom 404 Page',
		  'placeholder' => 'Select 404 Page',
		  'options'     => 'pages',
		  'dependency'   => array( '__custom_404_page', '==', true ),
		),
		array(
			'id'       => '__404_hero_text',
			'type'     => 'code_editor',
			'title'    => 'Text To Display',
			'subtitle' => '<strong>HTML Editor</strong> Using: theme: shadowfox and mode: htmlmixed',
			
			'default'  =>'<h1>Oops! That page can&rsquo;t be found.</h1>
<p>It looks like nothing was found at this location. Maybe try one of the links below or a search ?</p>',
			//'default'    => esc_url( $personal_cv_resume_default['__404_hero_text'] ),
			'dependency'   => array( '__custom_404_page', '==', false )
		),
			
			
			
	)
));


