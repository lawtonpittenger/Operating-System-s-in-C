<?php



// Create a section
CSF::createSection( $prefix, array(
	
	'title'  		=> __('Styling Options.','personal-cv-resume'),
	'id'    		=> 'common-Color',
	'icon'        	=> 'fa fa-object-group',
	'subtitleription' 	=>  __('Control the visual appearance of your theme, such as colors, layout and patterns, from here.','personal-cv-resume'),
	
	'fields' => array(
	
		array(
			'id'      => '__primary_color',
			'type'    => 'color',
			'title'   => __('Primary Color Scheme','personal-cv-resume'),
			'subtitle'    => __('The theme comes with unlimited color schemes for your theme\'s styling.','personal-cv-resume'),
			'default' => esc_attr( $personal_cv_resume_default['__primary_color'] )
		),
		array(
			'id'      => '__secondary_color',
			'type'    => 'color',
			'title'   => __('Secondary Color Scheme','personal-cv-resume'),
			'subtitle'    => __('The theme comes with unlimited color schemes for your theme\'s styling.','personal-cv-resume'),
			'default' => esc_attr( $personal_cv_resume_default['__secondary_color'] )
		),
		
		array(
			'id'      => '__tertiary_color',
			'type'    => 'color',
			'title'   => __('Tertiary Color Scheme','personal-cv-resume'),
			'subtitle'    => __('The theme comes with unlimited color schemes for your theme\'s styling.','personal-cv-resume'),
			'default' => esc_attr( $personal_cv_resume_default['__tertiary_color'] )
		),
		array(
			'id'      => '__quaternary_color',
			'type'    => 'color',
			'title'   => __('Quaternary Color Scheme','personal-cv-resume'),
			'subtitle'    => __('The theme comes with unlimited color schemes for your theme\'s styling.','personal-cv-resume'),
			'default' => esc_attr( $personal_cv_resume_default['__quaternary_color'] )
		),
		
		
		
	)
	
));

