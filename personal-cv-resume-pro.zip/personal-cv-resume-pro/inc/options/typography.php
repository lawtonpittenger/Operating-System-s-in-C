<?php


// Create a section
CSF::createSection( $prefix, array(
	'icon'        	=> 'fa fa-font',
	'title'  		=> __('Typography.','personal-cv-resume'),
	'id'    		=> 'typography',
	'fields' => array(
		
			array(
			  'id'             => '__content_font',
			  'type'           => 'typography',
			  'title'          => 'Body font',
			  'text_align'     => false,
			  'text_transform' => false,
			  'subset' 		   => false,
			  'color'          => false,
			  'default'        => $personal_cv_resume_default['__content_font'],
			    'unit'           => 'px',
			  'desc'     	   => __('Select body font and body font,size,line-height etc.','personal-cv-resume'),
			),
			array(
			  'id'             => '__heading_font',
			  'type'           => 'typography',
			  'title'          => 'Heading / hero font',
			  'text_align'     => false,
			  'text_transform' => false,
			  'subset' 		   => false,
			  'color'          => false,
			   'unit'           => 'rem',
			  'default'        => $personal_cv_resume_default['__heading_font'],
			  'desc'     	   => __('Select min page heading or hero block font size,line-height etc.','personal-cv-resume'),
			),
			array(
			  'id'             => '__heading_tags',
			  'type'           => 'typography',
			  'title'          => __('H Tags Font','personal-cv-resume'),
			  'text_align'     => false,
			  'text_transform' => false,
			  'subset' 		   => false,
			  'color'          => false,
			  'font_size'      => false,
			  'line_height'    => false,
			  'letter_spacing' => false,
			  'default'        => $personal_cv_resume_default['__heading_tags'],
			  'subtitle'    => __('The options apply whole h1,h2,h3,h4 etc, and font size will base on bootstrap','personal-cv-resume'),
			),
			array(
			  'id'             => '__widgets_heading_font',
			  'type'           => 'typography',
			  'title'          => 'Widgets heading',
			  'text_align'     => false,
			  'text_transform' => false,
			  'subset' 		   => false,
			  'color'          => false,
			   'unit'           => 'rem',
			  'default'        => $personal_cv_resume_default['__widgets_heading_font'],
			  'desc'     	   => __('Select min page heading or hero block font size,line-height etc.','personal-cv-resume'),
			),
			
			
		
		
	)
));










