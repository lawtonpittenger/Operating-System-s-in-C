<?php
if ( ! defined( 'ABSPATH' ) ) {
exit; // Exit if accessed directly.
}

// Create a section
CSF::createSection( $prefix, array(
	'icon'      => 'fa fa-newspaper-o',
	'id'    		=> '__general_options',
	'title'  		=> __('General Options','personal-cv-resume'),
	
));

// Create a section
CSF::createSection( $prefix, array(
'parent'        => '__general_options',	
'title'  		=> __('General Settings','personal-cv-resume'),
'icon' 			=> 'fa fa-tachometer',
'id'            => '__general',
'description' 	=>  __('This tab contains common setting options which will be applied to the whole theme.','personal-cv-resume'),

'fields' => array(

	 array(
	 
          'id'        => '__site_logo',
          'type'      => 'media',
          'title'     => __('Site Logo','personal-cv-resume'),
          'subtitle'      => __('Upload your site logo.','personal-cv-resume'),
		  'url'   => false,
     ),
	 array(
          'id'        => '__favicon',
          'type'      => 'media',
          'title'     => __('Favicon','personal-cv-resume'),
          'subtitle'      => __('Upload a 16 x 16 px image that will represent your website\'s favicon. You can refer to this link for more information on how to make it: <a href="'.esc_url( __( 'http://www.favicon.cc/', 'personal-cv-resume' )).'" target="_blank">http://www.favicon.cc/</a>.','personal-cv-resume'),
		  
		  'url'   => false,
        ),
   
   array(
	 
          'id'        => '__sidebar_header_bg',
          'type'      => 'media',
          'title'     => __('Sidebar Header Background','personal-cv-resume'),
          'subtitle'      => __('Upload your Sidebar background.','personal-cv-resume'),
		  'url'   => false,
     ),
	
	array(
		'id'           => '__site_bg_bg',
		'type'         => 'background',
		'title' 		 => esc_html__( 'Web Site background or color', 'personal-cv-resume' ),
	
	),	
	 array(
	 
      'id'       => '__header_code',
      'type'     => 'textarea',
      'title'    => 'Header Code',
      'subtitle'     => __('Enter the code which you need to place <strong>before closing  tag</strong>. (ex: Google Webmaster Tools verification, Bing Webmaster Center, BuySellAds Script, Alexa verification etc.)','personal-cv-resume'),
      'sanitize' => false,
     ),
	 
	 array(
	 
      'id'       => '__footer_code',
      'type'     => 'textarea',
      'title'    => 'Footer Code',
      'subtitle'     => __('Enter the codes which you need to place in your footer. <strong>(ex: Google Analytics, Clicky, STATCOUNTER, Woopra, Histats, etc.)</strong>.','personal-cv-resume'),
      'sanitize' => false,
    ),
		
	

)
) );



// Create a section
CSF::createSection( $prefix, array(
'parent'        => '__general_options',	
'title'  		=> __('Module Settings','personal-cv-resume'),
'icon' 			=> 'fa fa-tachometer',
'id'            => '__module',
'description' 	=>  __('This tab contains common setting options which will be applied to the whole theme.','personal-cv-resume'),

'fields' => array(
		array(
		  'id'      => '__page_loading',
		  'type'    => 'switcher',
		  'title'   => 'Page Loading ?',
		  'default' => true,
		  'default'    => esc_url( $personal_cv_resume_default['__page_loading'] ) 
		),

		array(
		  'id'      => '__page_aos',
		  'type'    => 'switcher',
		  'title'   => 'AOS - Animate  ?',
		  'default' => true,
		  'default'    => esc_url( $personal_cv_resume_default['__page_aos'] ) 
		),

		array(
		  'id'      => '__fly_sidebar',
		  'type'    => 'switcher',
		  'title'   => 'Fly Sidebar  ?',
		  'default' => true,
		  'default'    => esc_url( $personal_cv_resume_default['__fly_sidebar'] ) 
		),



)
) );	