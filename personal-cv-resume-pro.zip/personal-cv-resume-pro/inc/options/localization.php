<?php

// Create a section
CSF::createSection( $prefix, array(
	'icon'      => 'fa fa-pencil-square-o',
	'id'    		=> '__localization',
	'title'  		=> __('Localization','personal-cv-resume'),

	'fields' => array(
	
	    array(
		    'id'    => '__pcr_by_text',
		    'type'  => 'text',
		    'title' => esc_html__( 'Translate ( By )', 'personal-cv-resume' ),
		    'default'        => $personal_cv_resume_default['__pcr_by_text'],
		    'desc' => esc_html__( 'eave empty to hide this text','personal-cv-resume' )
		 ),
	     
	    array(
		    'id'    => '__pcr_posted_on',
		    'type'  => 'text',
		    'title' => esc_html__( 'Translate ( Posted on )', 'personal-cv-resume' ),
		    'default'        => $personal_cv_resume_default['__pcr_posted_on'],
		    'desc' => esc_html__( 'eave empty to hide this text','personal-cv-resume' )
		 ),

	    array(
		    'id'    => '__pcr_posted_in',
		    'type'  => 'text',
		    'title' => esc_html__( 'Translate ( Posted in )', 'personal-cv-resume' ),
		    'default'        => $personal_cv_resume_default['__pcr_posted_in'],
		    'desc' => esc_html__( 'eave empty to hide this text','personal-cv-resume' )
		 ),

	    array(
		    'id'    => '__pcr_tags_text',
		    'type'  => 'text',
		    'title' => esc_html__( 'Translate ( Tags )', 'personal-cv-resume' ),
		    'default'        => $personal_cv_resume_default['__pcr_tags_text'],
		    'desc' => esc_html__( 'eave empty to hide this text','personal-cv-resume' )
		 ),


	    array(
		    'id'    => '__pcr_share_this',
		    'type'  => 'text',
		    'title' => esc_html__( 'Translate ( Share this )', 'personal-cv-resume' ),
		    'default'        => $personal_cv_resume_default['__pcr_share_this'],
		    'desc' => esc_html__( 'eave empty to hide this text','personal-cv-resume' )
		 ),

	     array(
		    'id'    => '__readmore_text',
		    'type'  => 'text',
		    'title' => esc_html__( 'Translate ( Read More )', 'personal-cv-resume' ),
		    'default'        => $personal_cv_resume_default['__readmore_text'],
		    'desc' => esc_html__( 'eave empty to hide this text','personal-cv-resume' )
		 ),

		 array(
		    'id'    => '__readmore_text',
		    'type'  => 'text',
		    'title' => esc_html__( 'Translate ( Read More )', 'personal-cv-resume' ),
		    'default'        => $personal_cv_resume_default['__readmore_text'],
		    'desc' => esc_html__( 'eave empty to hide this text','personal-cv-resume' )
		 ),

		 array(
		    'id'    => '__pcr_previous_article',
		    'type'  => 'text',
		    'title' => esc_html__( 'Translate ( Previous Article )', 'personal-cv-resume' ),
		    'default'        => $personal_cv_resume_default['__pcr_previous_article'],
		    'desc' => esc_html__( 'eave empty to hide this text','personal-cv-resume' )
		 ),


		 array(
		    'id'    => '__pcr_next_article',
		    'type'  => 'text',
		    'title' => esc_html__( 'Translate ( Previous Article )', 'personal-cv-resume' ),
		    'default'        => $personal_cv_resume_default['__pcr_next_article'],
		    'desc' => esc_html__( 'eave empty to hide this text','personal-cv-resume' )
		 ),


		 array(
		    'id'    => '__pcr_name_text',
		    'type'  => 'text',
		    'title' => esc_html__( 'Translate ( Your Email )', 'personal-cv-resume' ),
		    'default' => $personal_cv_resume_default['__pcr_name_text'],
		    'desc'   => esc_html__( 'eave empty to hide this text','personal-cv-resume' )
		 ),

		 array(
		    'id'    => '__pcr_email_text',
		    'type'  => 'text',
		    'title' => esc_html__( 'Translate ( Your Email )', 'personal-cv-resume' ),
		    'default' => $personal_cv_resume_default['__pcr_email_text'],
		    'desc'   => esc_html__( 'eave empty to hide this text','personal-cv-resume' )
		 ),

		 array(
		    'id'    => '__pcr_website_text',
		    'type'  => 'text',
		    'title' => esc_html__( 'Translate ( Website )', 'personal-cv-resume' ),
		    'default' => $personal_cv_resume_default['__pcr_website_text'],
		    'desc'   => esc_html__( 'eave empty to hide this text','personal-cv-resume' )
		 ),

		 array(
		    'id'    => '__pcr_save_text',
		    'type'  => 'text',
		    'title' => esc_html__( 'Translate ( Save my name )', 'personal-cv-resume' ),
		    'default' => $personal_cv_resume_default['__pcr_save_text'],
		    'desc'   => esc_html__( 'eave empty to hide this text','personal-cv-resume' )
		 ),

		 array(
		    'id'    => '__pcr_comment_text',
		    'type'  => 'text',
		    'title' => esc_html__( 'Translate ( Comment )', 'personal-cv-resume' ),
		    'default' => $personal_cv_resume_default['__pcr_comment_text'],
		    'desc'   => esc_html__( 'eave empty to hide this text','personal-cv-resume' )
		 ),

		 array(
		    'id'    => '__pcr_post_comment',
		    'type'  => 'text',
		    'title' => esc_html__( 'Translate ( Post Comment )', 'personal-cv-resume' ),
		    'default' => $personal_cv_resume_default['__pcr_post_comment'],
		    'desc'   => esc_html__( 'eave empty to hide this text','personal-cv-resume' )
		 ),
	    
		 
		
	)
));
