<?php
// Set a unique slug-like ID
//
$prefix = '__personal_cv_resume_nav';

//
// Create menu options
//
CSF::createNavMenuOptions( $prefix, array(
  'data_type' => 'serialize'
) );

// Create a section
CSF::createSection( $prefix, array(
'fields' => array(

  array(
    'id'    => '__nav_icon',
    'type'  => 'icon',
    'title' => esc_html__( 'Menu Icon', 'personal-cv-resume' ),
  ),

)
) );