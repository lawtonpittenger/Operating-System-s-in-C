<?php

// Create a section
CSF::createSection( $prefix, array(
	'icon'      => 'fa fa-pencil-square-o',
	'id'    		=> 'footer',
	'title'  		=> __('Footer','personal-cv-resume'),
	'description' 	=>  __('This contains common setting options which will be applied to the whole site footer.','personal-cv-resume'),
	'fields' => array(
	
		array(
			  'id'    => '__footer_bg',
			  'type'  => 'background',
			  'title'     => esc_html__('Footer Background Image / Color.', 'personal-cv-resume'),
			  'desc' => esc_html__('Choose a color for footer background.', 'personal-cv-resume'),
			  'default'   => $personal_cv_resume_default['__footer_bg'],
			),
		
			
			array(
				'id'      => '__footer_link',
				'type'    => 'link_color',
				'title'   => 'link Color',
				'default' => $personal_cv_resume_default['__footer_link'],
				'subtitle'    => __('The theme comes with unlimited color schemes for your theme\'s styling.','personal-cv-resume'),
			),
		array(
		
		  'id'       => '__copyrights_text',
		  'type'     => 'textarea',
		  'title'    => 'Copyrights Text',
		  'subtitle'     => __('You can change or remove our link from footer and use your own custom text. (Link back is always appreciated)','personal-cv-resume'),
		  'sanitize' => false,
		  'default'  => esc_html( $personal_cv_resume_default['_copyrights_text'] )
		),

		array(
		  'id'     => 'social_wrap',
		  'type'   => 'repeater',
		  'title'  => __('Add your social profile','personal-cv-resume'),
		  'fields' => array(

			array(
			  'id'    => 'icon',
			  'type'  => 'icon',
			  'title' => __('Icon','personal-cv-resume'),
			),
			array(
			  'id'    => 'link',
			  'type'  => 'text',
			  'title' => __('Profile link','social_wrap'),
			),
			
			array(
				'id'      => 'bg',
				'type'    => 'color',
				'title'   => __('Icon color','personal-cv-resume'),
			),

		  ),
		 
		),
	
	 
	 array(
	 
          'id'      => '_cadires',
          'type'    => 'switcher',
          'title'   => __('Disable developer cadires ','personal-cv-resume'),
          'default' => esc_html( $personal_cv_resume_default['_cadires'] ),
		  'subtitle'    => __('Disable theme development cadires in footer.','personal-cv-resume')
        ),
		
	)
));
