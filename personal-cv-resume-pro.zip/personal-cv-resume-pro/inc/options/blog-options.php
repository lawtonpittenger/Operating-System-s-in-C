<?php
// Create a section
CSF::createSection( $prefix, array(
	'icon'      => 'fa fa-newspaper-o',
	'id'    		=> '__blog_options',
	'title'  		=> __('Blog Options','personal-cv-resume'),
	
));

// Create a section
CSF::createSection( $prefix, array(

	'parent'        => '__blog_options',
	'icon'        	=> 'cs-icon fa fa-minus',
	'id'    		=> 'page_layout',
	'title'  		=> __('Archive / Blog','personal-cv-resume'),
	'description' 	=>  __('This contains common setting options which will be applied to the whole site blog ( archive, category, tags, blog  ect)','personal-cv-resume'),
	'fields' => array(
	
		   array(
				'id'             => '__blog_layout',
				'type'           => 'select',
				'title'          => esc_html__('Blog Layout','personal-cv-resume'),
				'default'        => $personal_cv_resume_default['__blog_layout'],
				'options'        => array(
					'sidebar-content'  => esc_html__( 'Primary Sidebar / Content', 'personal-cv-resume' ),
					'right-sidebar' => esc_html__( 'Content / Primary Sidebar', 'personal-cv-resume' ),
					'full-container'    => esc_html__( 'No Sidebar', 'personal-cv-resume' ),
				),
				'subtitle'    => __('The options create your theme\'s blog / archive / category page layout.','personal-cv-resume'),
			),
			
	
		array(
		  'id'      => '__blog_template_layout',
		  'type'    => 'image_select',
		  'title'   => esc_html__('Blog Template Layout','personal-cv-resume'),
		  'default'  => $personal_cv_resume_default['__blog_template_layout'],
		  'options' => array(
			'standard' => get_theme_file_uri( '/inc/options/image/blog-type1.png' ),
			'sidepost' => get_theme_file_uri( '/inc/options/image/blog-type2.png' ),
			'grids' => get_theme_file_uri( '/inc/options/image/blog-type4.png' ),
			'masonry' => get_theme_file_uri( '/inc/options/image/blog-type6.png' ),
		  )
		),
			
			array(
				'id'             => '__blog_loop_desk',
				'type'           => 'select',
				'title'          => esc_html__('Desktop Columns ','personal-cv-resume'),
				'default'        => 'col-md-6',
				'options'        => array(
					'col-md-12'  		=> esc_html__( '1 Column', 'personal-cv-resume' ),
					'col-md-6'  		=> esc_html__( '2 Column', 'personal-cv-resume' ),
					'col-md-4'  		=> esc_html__( '3 Column', 'personal-cv-resume' ),
					'col-md-3'  		=> esc_html__( '4 Column', 'personal-cv-resume' ),
				),
				'subtitle'    => __('Set up grids layout for desktop.','personal-cv-resume'),
				'dependency' => array( '__blog_template_layout', 'any', 'grids,masonry' ),
			),
			
			array(
				'id'             => '__blog_loop_tab',
				'type'           => 'select',
				'title'          => esc_html__('Tablet Columns ','personal-cv-resume'),
				'default'        => $personal_cv_resume_default['__blog_loop_tab'],
				'options'        => array(
					'col-sm-12'  		=> esc_html__( '1 Column', 'personal-cv-resume' ),
					'col-sm-6'  		=> esc_html__( '2 Column', 'personal-cv-resume' ),
					'col-sm-4'  		=> esc_html__( '3 Column', 'personal-cv-resume' ),
					'col-sm-3'  		=> esc_html__( '4 Column', 'personal-cv-resume' ),
				),
				'subtitle'    => __('Set up grids layout for tablet.','personal-cv-resume'),
				'dependency' => array( '__blog_template_layout', 'any', 'grids,masonry' ),
			),
			array(
				'id'             => '__blog_loop_pho',
				'type'           => 'select',
				'title'          => esc_html__('Phone Columns ','personal-cv-resume'),
				'default'        => $personal_cv_resume_default['__blog_loop_pho'],
				'options'        => array(
					'col-12'  		=> esc_html__( '1 Column', 'personal-cv-resume' ),
					'col-6'  		=> esc_html__( '2 Column', 'personal-cv-resume' ),
					'col-4'  		=> esc_html__( '3 Column', 'personal-cv-resume' ),
					'col-3'  		=> esc_html__( '4 Column', 'personal-cv-resume' ),
				),
				'subtitle'    => __('Set up grids layout for phone.','personal-cv-resume'),
				'dependency' => array( '__blog_template_layout', 'any', 'grids,masonry' ),
			),
			
			array(
			  'id'      => '__blog_content',
			  'type'    => 'select',
			  'title'     => esc_html__('Content Type','personal-cv-resume'),
			  'options' => array(
				'excerpt'   => esc_html__('excerpt','personal-cv-resume'),
				'content'   => esc_html__('content','personal-cv-resume'),
				'no-content'   => esc_html__('no content','personal-cv-resume'),
			  ),
			  'attributes' => array(
					'style'    => 'width:200px',
				),
			  'default' => $personal_cv_resume_default['__blog_content'],
			  'subtitle'    => __('Select your theme\'s blog / archive / category posts loop content','personal-cv-resume'),
			),
			
			array(
			  'id'      => '__blog_pagination',
			  'type'    => 'select',
			  'title'     => esc_html__('Pagination Type','personal-cv-resume'),
			  'options' => array(
				'default'   => esc_html__('default','personal-cv-resume'),
				'numeric'   => esc_html__('Number list','personal-cv-resume'),
			  ),
			  'attributes' => array(
					'style'    => 'width:200px',
				),
			  'default' => $personal_cv_resume_default['__blog_pagination'],
			  'subtitle'    => __('Select Pagination Style for blog / archive / category','personal-cv-resume'),
			),
			
			array(
			  'id'       => '__blog_meta',
			  'type'     => 'checkbox',
			  'title'    => esc_html__('Posts Meta','personal-cv-resume'),
			  'options'  => array(
			 	
				'author'   => esc_html__('Author Name','personal-cv-resume'),
				'date' 	   => esc_html__('Posted Date','personal-cv-resume'),
				'comments' => esc_html__('Comment Count','personal-cv-resume'),
				'category' => esc_html__('Categories','personal-cv-resume'),
			  ), 
			  'default'    => $personal_cv_resume_default['__blog_meta'],
			  'subtitle'    => esc_html__('Check to show post meta on  your blog ( archive, category, tags, blog, single ).','personal-cv-resume'),
			),
			
			array(
				'id'             => '__archive_heading',
				'type'           => 'select',
				'title'          => esc_html__('Archive heading Tag ','personal-cv-resume'),
				'default'        => $personal_cv_resume_default['__archive_heading'],
				'options'        => array(
					'h1'  			=> esc_html__( 'H1', 'personal-cv-resume' ),
					'h2'  			=> esc_html__( 'H2', 'personal-cv-resume' ),
					'h3'  			=> esc_html__( 'H3', 'personal-cv-resume' ),
					'h4'  			=> esc_html__( 'H4', 'personal-cv-resume' ),
					'h5'  			=> esc_html__( 'H5', 'personal-cv-resume' ),
					'h6'  			=> esc_html__( 'H6', 'personal-cv-resume' ),
				),
			),
			
			array(
					'id'       => '__readmore_text',
					'type'     => 'text',
					'title'    => esc_html__('Archive Read more', 'business-consulting-pro'),
					'default'   => $personal_cv_resume_default['__readmore_text'],
					'subtitle'    => __('leave empty to hide','personal-cv-resume'),
			),
		
			
		
	)
));


// Create a section
CSF::createSection( $prefix, array(

	'parent'        => '__blog_options',
	'icon'        	=> 'cs-icon fa fa-minus',
	'id'    		=> '__blog_single_post',
	'title'  		=> __('Single','personal-cv-resume'),
	'fields' => array(
	
		
		array(
				'id'             => '__single_layout',
				'type'           => 'select',
				'title'          => esc_html__('Single Posts Layout ','personal-cv-resume'),
				'default'        => $personal_cv_resume_default['__single_layout'],
				'options'        => array(
					'sidebar-content'  => esc_html__( 'Primary Sidebar / Content', 'personal-cv-resume' ),
					'right-sidebar' => esc_html__( 'Content / Primary Sidebar', 'personal-cv-resume' ),
					'full-container'    => esc_html__( 'No Sidebar', 'personal-cv-resume' ),
					
				),
				'subtitle'    => __('The options create your theme\'s blog Single posts.','personal-cv-resume'),
			),
			array(
			  'id'       => '__single_post_meta',
			  'type'     => 'checkbox',
			  'title'    => esc_html__('Posts Meta','personal-cv-resume'),
			  'options'  => array(
			  	
				'author'   => esc_html__('Author Name','personal-cv-resume'),
				'date'  => esc_html__('Posted Date','personal-cv-resume'),
				'comments' => esc_html__('Comment Count','personal-cv-resume'),
				'category' => esc_html__('Categories','personal-cv-resume'),
				'tag' => esc_html__('Tag','personal-cv-resume'),
			  ), 
			  'default'    => $personal_cv_resume_default['__single_post_meta'],
			  'subtitle'    => esc_html__('Check to show post meta on  your blog ( archive, category, tags, blog, single ).','personal-cv-resume'),
			),
			
			array(
			  'id'    => '__single_post_featured',
			  'type'  => 'switcher',
			  'title' => esc_html__('Featured Image on Single Post','personal-cv-resume'),
			  'subtitle'    => esc_html__('turn on to show.','personal-cv-resume'),
			  'desc'    => __('Use this button if you want to show/hide the Featured Image.','personal-cv-resume'),
			  'default' => $personal_cv_resume_default['__single_post_featured'],
			),
			array(
			  'id'      => '__posts_share',
			  'type'    => 'switcher',
			  'title'     => __('Social Share Links','personal-cv-resume'),
			  'default' => $personal_cv_resume_default['__posts_share'],
			  'desc'    => __('By enabling this feature your visitors can share the post to social networks such as Facebook, Twitter and.....','personal-cv-resume'),
			),	
			
			array(
			  'id'    => '__single_post_nav',
			  'type'  => 'switcher',
			  'title' => esc_html__('Next and Previous post','personal-cv-resume'),
			  'subtitle'    => esc_html__('turn on to show.','personal-cv-resume'),
			  'desc'    => __('Use this button if you want to display next / previous button.','personal-cv-resume'),
			  'default' => $personal_cv_resume_default['__single_post_nav'],
			),
			
			array(
			  'id'      => '__single_post_author',
			  'type'    => 'switcher',
			  'title'     => __('Single post Authorbox','personal-cv-resume'),
			  'default' => $personal_cv_resume_default['__single_post_author'],
			  'desc'    => __('This feature shows a picture of post author and their info.','personal-cv-resume'),
			),	
			
			
		
	)
));

