<?php
// Create a section
CSF::createSection( $prefix, array(
	
	'title'  		=> __('Sidebar / Menu Settings.','personal-cv-resume'),
	'id'    		=> 'common-Color',
	'icon'        	=> 'fa fa-object-group',
	'subtitleription' 	=>  __('Control the visual appearance of your theme header part, such as colors, layout and patterns, from here.','personal-cv-resume'),
	
	'fields' => array(
		
		array(
			  'id'      => '__site_title_n_tagline',
			  'type'    => 'switcher',
			  'title'     => __('Site Title and Tagline','personal-cv-resume'),
			  'default' => $personal_cv_resume_default['__site_title_n_tagline'],
			  'subtitle'    => __('Use this button if you want to disable Title and Tagline.','personal-cv-resume'),
		),

		array(
			  'id'      => '__sidebar_slimscroll',
			  'type'    => 'switcher',
			  'title'     => __('SlimScroll','personal-cv-resume'),
			  'default' => $personal_cv_resume_default['__sidebar_slimscroll'],
			  'subtitle'    => __('If you used 2-3 level menu then disable.','personal-cv-resume'),
		),
		
	

		array(
				'id'      => '__navbar_link_color',
				'type'    => 'link_color',
				'title'   => __('Main Menu Color','personal-cv-resume'),
				'default' => $personal_cv_resume_default['__navbar_link_color'],
				'subtitle'    => __('The theme comes with unlimited color schemes for your theme\'s styling.','personal-cv-resume'),
		),

		array(
				'id'      => '__primary_menu_bg',
				'type'    => 'link_color',
				'title'   => __('Main Menu background','personal-cv-resume'),
				'subtitle'    => __('The theme comes with unlimited color schemes for your theme\'s styling.','personal-cv-resume'),
				
			),	
		 
		array(
	      'type'          => 'submessage',
	      'style'         => 'info',
	      'content'       => __('Drop download / submenu Settings','personal-cv-resume'),
	    ),
	    array(
				'id'      => '__sub_link_color',
				'type'    => 'link_color',
				'title'   => __('Main Menu Color','personal-cv-resume'),
				'subtitle'    => __('The theme comes with unlimited color schemes for your theme\'s styling.','personal-cv-resume'),
			),	
	    array(
				'id'      => '__sub_menu_bg',
				'type'    => 'link_color',
				'title'   => __('Submenu background','personal-cv-resume'),
				'subtitle'    => __('The theme comes with unlimited color schemes for your theme\'s styling.','personal-cv-resume'),
				
			),	
		 
		
		array(
			  'id'             => '__navbar_typography',
			  'type'           => 'typography',
			  'title'          =>  __('Main Menu Typography','personal-cv-resume'),
			  'text_align'     => false,
			  'subset' 		   => false,
			  'color'          => false,
			  'default'        => $personal_cv_resume_default['__navbar_typography'],
			    'unit'           => 'px',
			  'desc'     	   => __('Select Main Menu font,size,line-height etc.','personal-cv-resume'),
		),
		

		array(
		  'id'     => 'social_profile',
		  'type'   => 'repeater',
		  'title'  => __('Add your social profile','personal-cv-resume'),
		  'desc'     	   => __('leave empty to hide.','personal-cv-resume'),
		  'fields' => array(

			array(
			  'id'    => 'icon',
			  'type'  => 'icon',
			  'title' => __('Icon','personal-cv-resume'),
			),
			array(
			  'id'    => 'link',
			  'type'  => 'text',
			  'title' => __('Profile link','social_wrap'),
			),
			
			array(
				'id'      => 'bg',
				'type'    => 'color',
				'title'   => __('Background','personal-cv-resume'),
			),

		  ),
		  'default'     => $personal_cv_resume_default['social_wrap']
		),

		array(
			'id'           => '__site_nav_sidebar_bg',
			'type'         => 'background',
			'title' 		 => esc_html__( 'Sidebar background or color', 'personal-cv-resume' ),

		),		
		
	)
	
));


?>