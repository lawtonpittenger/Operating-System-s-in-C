<?php
/**
 * Diet Theme Options
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Diet_Shop
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) :

  //
  // Set a unique slug-like ID
  $prefix = '__gs_header_meta';

  $array = array('post','page','product');
 
/*  if( ( is_page() &&  inx_get_option('_page_style') != 'hero-block' ) ){
	unset($array[1]);  
  }*/

  
  CSF::createMetabox( $prefix, array(
    'title'     => 'Background Options',
    /*'context'	=> 'side',*/
    'post_type' =>  $array,
    'priority'  => 'high',

  ) );



  //
  // Create a section
  CSF::createSection( $prefix, array(
    'fields' => array(
		
      // A text field
			array(
				'id'      => '_page_hero_bg',
				'type'    => 'background',
				'title'   => esc_html__( 'Page Background', 'personal-cv-resume' ),
				'subtitle' => esc_html__( 'Leave empty to inherit theme option', 'personal-cv-resume' ),
			),
	
    )
  ) );


CSF::createMetabox( 'project_gallery', array(
    'title'     => 'Project Gallery',
    /*'context' => 'side',*/
    'post_type' =>  array('project'),
    'priority'  => 'high',

  ) );



  //
  // Create a section
  CSF::createSection( 'project_gallery', array(
    'fields' => array(
    
      // A text field
      array(
      'id'    => 'project_gallery',
      'type'  => 'gallery',
      'title' => 'Gallery',
      ),

     array(
        'id'             => '__gallery_desk',
        'type'           => 'select',
        'title'          => esc_html__('Desktop Columns ','personal-cv-resume'),
        'default'        => 'col-md-3',
        'options'        => array(
          'col-md-12'     => esc_html__( '1 Column', 'personal-cv-resume' ),
          'col-md-6'      => esc_html__( '2 Column', 'personal-cv-resume' ),
          'col-md-4'      => esc_html__( '3 Column', 'personal-cv-resume' ),
          'col-md-3'      => esc_html__( '4 Column', 'personal-cv-resume' ),
        ),
        'subtitle'    => __('Set up galleries layout for desktop.','personal-cv-resume'),
      ),
      
      array(
        'id'             => '__gallery_tab',
        'type'           => 'select',
        'title'          => esc_html__('Tablet Columns ','personal-cv-resume'),
        'default'        => 'col-sm-6',
        'options'        => array(
          'col-sm-12'     => esc_html__( '1 Column', 'personal-cv-resume' ),
          'col-sm-6'      => esc_html__( '2 Column', 'personal-cv-resume' ),
          'col-sm-4'      => esc_html__( '3 Column', 'personal-cv-resume' ),
          'col-sm-3'      => esc_html__( '4 Column', 'personal-cv-resume' ),
        ),
        'subtitle'    => __('Set up galleries layout for tablet.','personal-cv-resume'),
      ),
      array(
        'id'             => '__gallery_pho',
        'type'           => 'select',
        'title'          => esc_html__('Phone Columns ','personal-cv-resume'),
        'default'        => 'col-12',
        'options'        => array(
          'col-12'      => esc_html__( '1 Column', 'personal-cv-resume' ),
          'col-6'     => esc_html__( '2 Column', 'personal-cv-resume' ),
          'col-4'     => esc_html__( '3 Column', 'personal-cv-resume' ),
          'col-3'     => esc_html__( '4 Column', 'personal-cv-resume' ),
        ),
        'subtitle'    => __('Set up galleries layout for phone.','personal-cv-resume'),
        
      ),
  
    )
  ) );

endif;






