<?php

// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

CSF::createWidget( 'pcr_about_me', array(
    'title'       => '+ About Me',
    'classname'   => 'pcr-branding',
    'description' => 'A Widget for about me in sidebar. ',
    'fields'      => array(

      array(
        'id'      => 'title',
        'type'    => 'text',
        'title'   => 'Title',
      ),

     array(
      'id'        => '_site_logo',
      'type'      => 'media',
      'title'     => __('Site Logo','personal-cv-resume'),
      'subtitle'      => __('Upload your site logo.','personal-cv-resume'),
      'url'   => false,
    ),

    array(
      'id'      => '__brand_description',
      'type'    => 'textarea',
      'title'   => 'Textarea',
      'help'    => 'Add yourbrand here.',
    ),
    
    array(
      'id'     => '__contact_info',
      'type'   => 'repeater',
      'title'  => __('Contact Info.','personal-cv-resume'),
      'subtitle'     => __('Add your Contact Info','personal-cv-resume'),
      'fields' => array(
      
          array(
            'id'      => 'icon',
            'type'    => 'icon',
            'title'   => 'Icon',
          ),
          array(
            'id'    => 'text',
            'type'  => 'text',
            'title' => 'Text',
          ),
      ),
      
    ),
      
  array(
      'id'     => '__socail_icon',
      'type'   => 'repeater',
      'title'  => __('Social Profiles.','personal-cv-resume'),
      'subtitle'     => __('Add your Social Profiles and link','personal-cv-resume'),
      'fields' => array(
      
          array(
            'id'      => 'icon',
            'type'    => 'icon',
            'title'   => 'Icon',
          ),
          array(
            'id'    => 'text',
            'type'  => 'text',
            'title' => 'Text',
          ),
      ),
      
    ),
    
    
  
    )
  ) );

  //
  // Front-end display of widget example 1
  // Attention: This function named considering above widget base id.
  //
  if( ! function_exists( 'pcr_about_me' ) ) {
    function pcr_about_me( $args, $instance ) {

  echo $args['before_widget'];
    
    if ( ! empty( $instance['title'] ) ) {
        echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
      }
  echo '<div class="site-info-widget">';

    if( !empty( $instance["_site_logo"]['url'] ) ):
      echo '<div class="branding-logo"><img src="'. esc_url( $instance["_site_logo"]['url'] ) .'" alt="'.get_bloginfo( 'name' ).'"></div>';
    endif;  

    if( !empty($instance["__brand_description"]) ):
    echo '<div class="branding-text">';  
    echo esc_html( $instance["__brand_description"]);
    echo '</div>';
    endif;
  
  

       if( !empty($instance['__contact_info']) ):
        echo '<ul class="contact-info-list">';
        foreach ($instance['__contact_info'] as $row) :
        echo '<li><i class="'.esc_html( $row['icon'] ).'"></i> '.esc_html( $row['text'] ).'</li>';

        endforeach;
        echo '</ul>';
      endif;


      if( !empty($instance['__socail_icon']) ):
        echo '<ul class="social-links">';
        foreach ($instance['__socail_icon'] as $row) :
        echo '<li><a href="'.esc_html( $row['text'] ).'"><i class="'.esc_html( $row['icon'] ).'"></i></a></li>';

        endforeach;
        echo '</ul>';
      endif;
      echo '</div>';

      echo $args['after_widget'];

    
  }

}

}