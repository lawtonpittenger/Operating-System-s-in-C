<?php

$custom_css .= ':root {';
	
	if( !empty( personal_cv_resume_get_option( '__primary_color' ) ) ):
	   $custom_css .= '--primary-color:'. esc_attr( personal_cv_resume_get_option( '__primary_color' ) ).';';
	endif;

	if( !empty( personal_cv_resume_get_option( '__secondary_color' ) ) ):
	   $custom_css .= '--secondary-color:'. esc_attr( personal_cv_resume_get_option( '__secondary_color' ) ).';';
	endif;

	if( !empty( personal_cv_resume_get_option( '__tertiary_color' ) ) ):
	   $custom_css .= '--tertiary-color:'. esc_attr( personal_cv_resume_get_option( '__tertiary_color' ) ).';';
	endif;

	if( !empty( personal_cv_resume_get_option( '__quaternary_color' ) ) ):
	   $custom_css .= '--quaternary-color:'. esc_attr( personal_cv_resume_get_option( '__quaternary_color' ) ).';';
	endif;

	if( !empty( personal_cv_resume_get_option( '__navbar_link_color' )['color'] ) ):
	   $custom_css .= '--nav-color:'. esc_attr( personal_cv_resume_get_option( '__navbar_link_color' )['color'] ).';';
	endif;
	
	if( !empty( personal_cv_resume_get_option( '__navbar_link_color' )['hover'] ) ):
	   $custom_css .= '--nav-h-color:'. esc_attr( personal_cv_resume_get_option( '__navbar_link_color' )['hover'] ).';';
	endif;

	if( !empty( personal_cv_resume_get_option( '__navbar_link_color' )['hover'] ) ):
	   $custom_css .= ' --secondary-color-rgb:'. esc_attr( __hex2rgba(personal_cv_resume_get_option( '__secondary_color' ),0.35 ) ).';';
	endif;
	if( !empty( personal_cv_resume_get_option( '__navbar_link_color' )['hover'] ) ):
	   $custom_css .= ' --secondary-color-rgb-deep:'. esc_attr( __hex2rgba(personal_cv_resume_get_option( '__secondary_color' ),0.65 ) ).';';
	endif;

	
$custom_css .= '}';

if( !empty( personal_cv_resume_get_option('__site_bg_bg') ) ):
$custom_css .= 'body{'.  __bg_render(personal_cv_resume_get_option('__site_bg_bg') ) .'}';
endif;
/*----------------Navigation ----------------------*/

if( !empty( personal_cv_resume_get_option( '__primary_menu_bg' )['color'] ) ):
$custom_css .= '#aside-nav-wrapper #navbar ul > li > a{background:'.esc_attr( personal_cv_resume_get_option( '__primary_menu_bg' )['color'] ).'}';

endif;

if( !empty( personal_cv_resume_get_option( '__primary_menu_bg' )['hover'] ) ):
$custom_css .= '#aside-nav-wrapper #navbar ul > li > a:hover, #aside-nav-wrapper #navbar ul > li > a:focus,#aside-nav-wrapper #navbar ul > li.current-menu-item > a{background:'.esc_attr( personal_cv_resume_get_option( '__primary_menu_bg' )['hover'] ).'}';

endif;

if( !empty( personal_cv_resume_get_option( '__sub_link_color' )['color'] ) ):
$custom_css .= '#aside-nav-wrapper #navbar li li > a, #aside-nav-wrapper #navbar li li.current-menu-item > a{color:'.esc_attr( personal_cv_resume_get_option( '__sub_link_color' )['color'] ).'}';


endif;

if( !empty( personal_cv_resume_get_option( '__sub_link_color' )['hover'] ) ):
$custom_css .= '#aside-nav-wrapper #navbar li li > a:hover,#aside-nav-wrapper #navbar li li > a:focus,#aside-nav-wrapper #navbar li li.current-menu-item > a{color:'.esc_attr( personal_cv_resume_get_option( '__sub_link_color' )['hover'] ).'}';
$custom_css .= '#aside-nav-wrapper #navbar li ul > li > a::before{background:'.esc_attr( personal_cv_resume_get_option( '__sub_link_color' )['hover'] ).'!important;}';
$custom_css .= '#aside-nav-wrapper #navbar ul ul li:first-child::before{border-right: 8px solid '.esc_attr( personal_cv_resume_get_option( '__sub_link_color' )['hover'] ).'!important;}';

endif;

if( !empty( personal_cv_resume_get_option( '__sub_menu_bg' )['color'] ) ):
	$custom_css .= '#aside-nav-wrapper #navbar ul ul{background:'.esc_attr( personal_cv_resume_get_option( '__sub_menu_bg' )['color'] ).'}';
endif;

if( !empty( personal_cv_resume_get_option( '__sub_menu_bg' )['hover'] ) ):
	$custom_css .= '#aside-nav-wrapper #navbar li li > a:hover,#aside-nav-wrapper #navbar li li > a:focus,#aside-nav-wrapper #navbar li li.current-menu-item > a{background:'.esc_attr( personal_cv_resume_get_option( '__sub_menu_bg' )['hover'] ).'}';
endif;

if( !empty( personal_cv_resume_get_option('__navbar_typography') ) ){

	$nav_fonts 		= personal_cv_resume_get_option('__navbar_typography');
	$sub_menu		= personal_cv_resume_get_option('__navbar_typography');

	$custom_css 	.= '#aside-nav-wrapper #navbar ul > li > a {'.__font_render( $nav_fonts ).'}';
	

	$sub_menu['font-size'] = absint( $nav_fonts['font-size'] ) - 2;
	$sub_menu['letter-spacing']  = '';
	$sub_menu['text-transform']  = '';
	$sub_menu['line-height']  	 = '';
	$custom_css 	.= '#aside-nav-wrapper #navbar li li > a {'.__font_render( $sub_menu ).'}';
}

if( !empty( personal_cv_resume_get_option('__site_nav_sidebar_bg') ) ):
$custom_css .= '#aside-nav-wrapper.fixed,#aside-nav-wrapper .wp-header-image::before, #aside-nav-wrapper .wp-header-image::after{'.  __bg_render(personal_cv_resume_get_option('__site_nav_sidebar_bg') ) .'}';
endif;

/*---------------- End Navigation ----------------------*/

if( !empty( personal_cv_resume_get_option('__footer_bg') ) ):
$custom_css .= '#colophon.site-footer{'.  __bg_render(personal_cv_resume_get_option('__footer_bg') ) .'}';
endif;


if( !empty( personal_cv_resume_get_option( '__footer_link' )['color'] ) ):
	$custom_css .= '#colophon.site-footer .text{color:'.esc_attr( personal_cv_resume_get_option( '__footer_link' )['color'] ).'}';
endif;
if( !empty( personal_cv_resume_get_option( '__footer_link' )['hover'] ) ):
	$custom_css .= '#colophon.site-footer .text a{color:'.esc_attr( personal_cv_resume_get_option( '__footer_link' )['hover'] ).'}';
endif;
if( !empty( personal_cv_resume_get_option( '__footer_link' )['color'] ) ):
	$custom_css .= '#colophon.site-footer .text a:hover,#colophon.site-footer .text a:focus{color:'.esc_attr( personal_cv_resume_get_option( '__footer_link' )['color'] ).'}';
endif;

$meta 			= get_post_meta( get_the_ID(), '__gs_header_meta', true );

if( !empty($meta["_page_hero_bg"] ) ){

	$custom_css .= '#page.site{'.  __bg_render($meta["_page_hero_bg"]) .'}';


}

 
