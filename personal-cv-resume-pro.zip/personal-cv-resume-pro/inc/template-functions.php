<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package emart-shop
 */

function personal_cv_resume_body_classes( $classes ) {
	// Adds a class of hfeed to non-singular pages.
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}

	// Adds a class of no-sidebar when there is no sidebar present.
	if ( ! is_active_sidebar( 'sidebar-1' ) ) {
		$classes[] = 'no-sidebar';
	}

	return $classes;
}
add_filter( 'body_class', 'personal_cv_resume_body_classes' );

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function personal_cv_resume_pingback_header() {
	if ( is_singular() && pings_open() ) {
		printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
	}
}
add_action( 'wp_head', 'personal_cv_resume_pingback_header' );

if ( ! function_exists( 'personal_cv_resume_alowed_tags' ) ) :
	/**
	 * @see diet_shop_alowed_tags().
	 */
function personal_cv_resume_alowed_tags() {
	
	
	$wp_post_allow_tag = wp_kses_allowed_html( 'post' );
	
	$allowed_tags = array(
		'a' => array(
			'class' => array(),
			'href'  => array(),
			'rel'   => array(),
			'title' => array(),
			'id'	=> array(),
			'target'=> array(),
			'style'=> array(),
		),
		'abbr' => array(
			'title' => array(),
		),
		'b' => array(),
		'blockquote' => array(
			'cite'  => array(),
		),
		'cite' => array(
			'title' => array(),
		),
		'code' => array(),
		'del' => array(
			'datetime' => array(),
			'title' => array(),
		),
		'dd' => array(),
		'div' => array(
			'class' => array(),
			'title' => array(),
			'style' => array(),
			'id' => array(),
		),
		'dl' => array( 
			'class' => array(),
			'style' => array(),
			'id' => array(),
		),
		'dt' => array(
			'class' => array(),
			'style' => array(),
			'id' => array(),
		),
		'em' => array(
			'class' => array(),
			'style' => array(),
			'id' => array(),
		),
		'h1' => array(
			'class' => array(),
			'title' => array(),
			'style' => array(),
			'id' => array(),
		
		),
		'h2' => array(
			'class' => array(),
			'style' => array(),
			'id' => array(),
		
		),
		'h3' => array(
			'class' => array(),
			'style' => array(),
			'id' => array(),
		),
		'h4' => array(
			'class' => array(),
			'style' => array(),
			'id' => array(),
		),
		'h5' => array(
			'class' => array(),
			'style' => array(),
			'id' => array(),
		),
		'h6' => array(
			'class' => array(),
			'style' => array(),
			'id' => array(),
		),
		'i' => array(
			'class' => array(),
			'style' => array(),
			'id' => array(),
		),
		'img' => array(
			'alt'    => array(),
			'class'  => array(),
			'height' => array(),
			'src'    => array(),
			'width'  => array(),
		),
		'li' => array(
			'class' => array(),
			'style' => array(),
			'id' => array(),
		),
		'i' => array(
			'class' => array(),
			'style' => array(),
			'id' => array(),
		),
		'ol' => array(
			'class' => array(),
			'style' => array(),
			'id' => array(),
		),
		'p' => array(
			'class' => array(),
			'style' => array(),
			'id' => array(),
		),
		'q' => array(
			'cite' => array(),
			'title' => array(),
		),
		'span' => array(
			'class' => array(),
			'style' => array(),
			'id' => array(),
		),
		'strike' => array(),
		'strong' => array(),
		'ul' => array(
			'class' => array(),
			'style' => array(),
			'id' => array(),
		),
		'iframe' => array(
			'src'             => array(),
			'height'          => array(),
			'width'           => array(),
			'frameborder'     => array(),
			'allowfullscreen' => array(),
		),
		'time' => array(
			'class' => array(),
			'title' => array(),
			'style' => array(),
			'datetime' => array(),
			'content' => array(),
		),
		'main' => array(
			'class' => array(),
			'id' => array(),
			'style' => array(),
			
		),
	);

	
	$tags = array_merge( $wp_post_allow_tag, $allowed_tags );

	return apply_filters( 'personal_cv_resume_alowed_tags', $tags );
	
}
endif;



if ( ! function_exists( 'personal_cv_resume_walker_comment' ) ) : 
	/**
	 * Implement Custom Comment template.
	 *
	 * @since 1.0.0
	 *
	 * @param $comment, $args, $depth
	 * @return $html
	 */
	  
	function personal_cv_resume_walker_comment($comment, $args, $depth) {
		if ( 'div' === $args['style'] ) {
			$tag       = 'div';
			$add_below = 'comment';
		} else {
			$tag       = 'li';
			$add_below = 'div-comment';
		}
		?>
		<li <?php comment_class( empty( $args['has_children'] ) ? 'comment shift' : 'comment' ) ?> id="comment-<?php comment_ID() ?>">

           <div class="single-comment clearfix d-flex">
           	
				 <?php if ( $args['avatar_size'] != 0 ) echo get_avatar( $comment, 80,'','', array('class' => 'float-left') ); ?>
                <div class="comment float-left">
                    <h6><?php echo get_comment_author_link();?></h6>
                    <div class="date"> 
                        <?php
                            /* translators: 1: date, 2: time */
                            printf( esc_html__('%1$s at %2$s', 'emart-shop' ), esc_html( get_comment_date() ),  esc_html( get_comment_time()) ); 
                        ?>
                    </div>
                    
                    <div class="reply"> <?php comment_reply_link( array_merge( $args, array( 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?></div>
                            
                   
                    <div class="comment-text"><?php comment_text(); ?></div>
                </div>
            </div>
			<div class="clearfix"></div>
	   </li>
       <?php
	}
	
	
endif;


if ( ! function_exists( 'emart_walker_comment' ) ) : 
	/**
	 * Implement Custom Comment template.
	 *
	 * @since 1.0.0
	 *
	 * @param $comment, $args, $depth
	 * @return $html
	 */
	  
	function emart_walker_comment($comment, $args, $depth) {
		if ( 'div' === $args['style'] ) {
			$tag       = 'div';
			$add_below = 'comment';
		} else {
			$tag       = 'li';
			$add_below = 'div-comment';
		}
		?>
		<li <?php comment_class( empty( $args['has_children'] ) ? 'comment shift' : 'comment' ) ?> id="comment-<?php comment_ID() ?>">
           <div class="single-comment clearfix">
				 <?php if ( $args['avatar_size'] != 0 ) echo get_avatar( $comment, 80,'','', array('class' => 'float-left') ); ?>
                <div class="comment float-left">
                    <h6><?php echo get_comment_author_link();?></h6>
                    <div class="date"> 
                        <?php
                            /* translators: 1: date, 2: time */
                            printf( esc_html__('%1$s at %2$s', 'emart-shop' ), esc_html( get_comment_date() ),  esc_html( get_comment_time()) ); 
                        ?>
                    </div>
                    
                    <div class="reply"> <?php comment_reply_link( array_merge( $args, array( 'depth' => $depth, 'max_depth' => $args['max_depth'] ) ) ); ?></div>
                            
                   
                    <div class="comment-text"><?php comment_text(); ?></div>
                </div>
            </div>
			<div class="clearfix"></div>
	   </li>
       <?php
	}
	
	
endif;


class personal_cv_resume_navwalker extends Walker_Nav_Menu {
		/**
		 * Menu Fallback
		 * =============
		 * If this function is assigned to the wp_nav_menu's fallback_cb variable
		 * and a menu has not been assigned to the theme location in the WordPress
		 * menu manager the function with display nothing to a non-logged in user,
		 * and will add a link to the WordPress menu manager if logged in as an admin.
		 *
		 * @param array $args passed from the wp_nav_menu function.
		 */
		public static function fallback( $args ) {
			
			wp_nav_menu( array(
				'depth'             => 1,
				'menu_class'  		=> 'emart-main-menu navigation-menu',
				'container'			=>'ul',
				'theme_location'    => 'fallback_menu'
			) );
			
		}

		public static function fallback_2( $args ) {
			if ( current_user_can( 'edit_theme_options' ) ) {

				echo '<ul>';
				echo '<li><a href="' . esc_url( admin_url( 'nav-menus.php' ) ) . '" title="">' . esc_html__( 'Add a menu', 'emart-shop' ) . '</a></li>';
				echo '</ul>';
				
			}
		}

	public function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {

		
	    $meta = get_post_meta( $item->ID, '__personal_cv_resume_nav', true );
	   

	    if( ! empty( $meta['__nav_icon'] ) ) {
	      $item->title = '<i class="nav-icon '. $meta['__nav_icon'] .'"></i>' . $item->title;
	    }
    	
    	if( !empty($item->url) && !wp_http_validate_url(esc_url_raw($item->url)) ){
		
			$url = ( get_permalink( get_the_ID() ) !=  get_home_url().'/' ) ? get_home_url().'/' :'';

			if( preg_match('/#/', $item->url) ){
				$item->url = esc_url( $url ).$item->url;
			}else{
				$item->url = esc_url( $url ).'#'.$item->url;
			}
 		
 		}

      parent::start_el( $output, $item, $depth, $args, $id );

    }
 
}


function __hex2rgba($color, $opacity = false) {
    $default = 'rgb(0,0,0)';    
    
    if (empty($color))
        return $default;    

    if ($color[0] == '#')
        $color = substr($color, 1);
    
    if (strlen($color) == 6)
        $hex = array($color[0] . $color[1], $color[2] . $color[3], $color[4] . $color[5]);
    
    elseif (strlen($color) == 3)
        $hex = array($color[0] . $color[0], $color[1] . $color[1], $color[2] . $color[2]);
    
    else
        return $default;
       
    $rgb = array_map('hexdec', $hex);    

    if ($opacity) {
        if (abs($opacity) > 1)
            $opacity = 1.0;

        $output = 'rgba(' . implode(",", $rgb) . ',' . $opacity . ')';
    } else {
        $output = 'rgb(' . implode(",", $rgb) . ')';
    }    
    return $output;
}


function __color_rightness($hexCode, $adjustPercent) {
    $hexCode = ltrim($hexCode, '#');

    if (strlen($hexCode) == 3) {
        $hexCode = $hexCode[0] . $hexCode[0] . $hexCode[1] . $hexCode[1] . $hexCode[2] . $hexCode[2];
    }

    $hexCode = array_map('hexdec', str_split($hexCode, 2));

    foreach ($hexCode as & $color) {
        $adjustableLimit = $adjustPercent < 0 ? $color : 255 - $color;
        $adjustAmount = ceil($adjustableLimit * $adjustPercent);

        $color = str_pad(dechex($color + $adjustAmount), 2, '0', STR_PAD_LEFT);
    }

    return '#' . implode($hexCode);
}


function __bg_render( $arr = array() ) { 
	
	if( empty( $arr ) ){ return false; }
	
	$css = '';
	
	$position 	= !empty( $arr['background-position'] ) 	 ? $arr['background-position'] : '';
	$repeat 	= !empty( $arr['background-repeat'] )		 ? $arr['background-repeat'] : '';
	$color 		= !empty( $arr['background-color'] )		 ? $arr['background-color'] : '';
	
	if( !empty( $arr['background-image']['url'] ) ){
		
		$css 	.= 'background:url( '.esc_url( $arr['background-image']['url'] ).' ) '. $position.' '.$repeat.' '.$color.'!important;';
		
	}else{
		if( !empty( $color ) )
		$css 	.= 'background-color:'.esc_attr( $color ).'!important;';
	}
	
		$css 		.= !empty( $arr['background-size'] )		 ? ' -webkit-background-size:'.$arr['background-size'].'!important;  background-size:'.$arr['background-size'].'!important;': '';
	
	return $css ;
}

function __font_render( $arr = array() ) { 
	
	if( empty( $arr ) ){ return false; }
	
	$unit		= !empty( $arr['unit'] )		 		? $arr['unit'] : 'px';
	$css		='';
	$css 	   .= !empty( $arr['font-family'] ) 	 	? "font-family:'".esc_attr( $arr['font-family'] )."', sans-serif; " : '';

	$css 	   .= !empty( $arr['font-weight'] ) 	 	? "font-weight:".esc_attr( $arr['font-weight'] )."; " : '';
	
	$css 	   .= !empty( $arr['font-style'] ) 	 		? "font-style:".esc_attr( $arr['font-style'] )."; " : '';
	$css 	   .= !empty( $arr['font-size'] ) 	 		? "font-size:".esc_attr( $arr['font-size'] ).$unit."; " : '';
	$css 	   .= !empty( $arr['line-height'] ) 	 	? "line-height:".esc_attr( $arr['line-height'] ).$unit."; " : '';
	$css 	   .= !empty( $arr['letter-spacing'] ) 	 	? "letter-spacing:".esc_attr( $arr['letter-spacing'] ).$unit."; " : '';
	$css 	   .= !empty( $arr['text-align'] ) 	 		? "text-align:".esc_attr( $arr['text-align'] )."; " : '';
	$css 	   .= !empty( $arr['color'] ) 	 			? "color:".esc_attr( $arr['color'] )."; " : '';
	$css 	   .= !empty( $arr['text-transform'] ) 	 	? "text-transform:".esc_attr( $arr['text-transform'] )."; " : '';
	
	return $css ;
}

function __hex2rgb( $hex ) {

 if( preg_match("/#/i", $hex ) ){
	  $hex = str_replace("#", "", $hex);

	   if(strlen($hex) == 3) {
	      $r = hexdec(substr($hex,0,1).substr($hex,0,1));
	      $g = hexdec(substr($hex,1,1).substr($hex,1,1));
	      $b = hexdec(substr($hex,2,1).substr($hex,2,1));
	   } else {
	      $r = hexdec(substr($hex,0,2));
	      $g = hexdec(substr($hex,2,2));
	      $b = hexdec(substr($hex,4,2));
	   }
	   $hex = $r.','. $g.','. $b;
  }

  return $hex;     
}


if( !function_exists('personal_cv_resume_elementor_editor_simplify') ){
	
	function personal_cv_resume_elementor_editor_simplify(){
		
		add_action( 'wp_head', function () {
				echo '<style type="text/css">
				#elementor-panel-category-pro-elements,
				#elementor-panel-category-theme-elements,
				#elementor-panel-category-woocommerce-elements,
				#elementor-panel-get-pro-elements{
					display:none!important;	
				}
				#e-notice-bar{
					display:none!important;	
				}
				#elementor-preview-iframe [data-aos^="fade"][data-aos^="fade"]{
					opacity: 1!important;
				}
				</style>';
			}  );
		
	}
	add_action( 'elementor/editor/init', 'personal_cv_resume_elementor_editor_simplify');

}

add_filter( 'use_widgets_block_editor', '__return_false' );

add_filter( 'widget_text', 'do_shortcode' );



add_filter( 'personal_cv_resume_custom_header_args', 'personal_cv_resume_custom_header_args' );

function personal_cv_resume_custom_header_args( $args ){

	if( !empty( personal_cv_resume_get_option('__sidebar_header_bg') ) ){
		$args['default-image'] = personal_cv_resume_get_option('__sidebar_header_bg')['url'];
	}
	return $args;
}


function personal_cv_resume_template_redirect(){
	
if( is_404() && personal_cv_resume_get_option('__custom_404_page') == true && !empty( personal_cv_resume_get_option('__custom_404_page_id') )   ):
	
	wp_redirect( get_the_permalink( personal_cv_resume_get_option('__custom_404_page_id') ), 301 );
	exit;
 endif;
  
}
add_action( 'template_redirect', 'personal_cv_resume_template_redirect' );


if( ! function_exists( 'personal_cv_resume_demo_import_files' ) ) :
	/**
	*
	*/
	
	function personal_cv_resume_demo_import_files() {
		$array = array(
			array(
				'import_file_name'			=> esc_html__( 'One Page Theme', 'personal-cv-resume' ),
				
				'local_import_file'			=> trailingslashit( get_template_directory() ) . 'inc/demo-data/demo-1.xml',
				
				'local_import_widget_file'     => trailingslashit( get_template_directory() ) . 'inc/demo-data/demo-1.wie',
				
				'import_notice'				=> esc_html__( 'After import demo data, just set static homepage from settings > reading, check widgets & menus.', 'personal-cv-resume' ),
				'import_preview_image_url'     => 'https://demo.athemeart.com/pcr/img/demo-1.png',
				'preview_url'                => 'https://demo.athemeart.com/pcr/demo-1/',
			),

			array(
				'import_file_name'			=> esc_html__( 'Standard page', 'personal-cv-resume' ),
				
				'local_import_file'			=> trailingslashit( get_template_directory() ) . 'inc/demo-data/demo-2.xml',
				
				'local_import_widget_file'     => trailingslashit( get_template_directory() ) . 'inc/demo-data/demo-2.wie',
				
				'import_notice'				=> esc_html__( 'After import demo data, just set static homepage from settings > reading, check widgets & menus.', 'personal-cv-resume' ),
				'import_preview_image_url'     => 'https://demo.athemeart.com/pcr/img/demo-2.png',
				'preview_url'                => 'https://demo.athemeart.com/pcr/demo-2/',
			),

			array(
				'import_file_name'			=> esc_html__( 'Blog Variation layout', 'personal-cv-resume' ),
				
				'local_import_file'			=> trailingslashit( get_template_directory() ) . 'inc/demo-data/demo-3.xml',
				
				'local_import_widget_file'     => trailingslashit( get_template_directory() ) . 'inc/demo-data/demo-3.wie',
				
				'import_notice'				=> esc_html__( 'After import demo data, just set static homepage from settings > reading, check widgets & menus.', 'personal-cv-resume' ),
				'import_preview_image_url'     => 'https://demo.athemeart.com/pcr/img/demo-3.png',
				'preview_url'                => 'https://demo.athemeart.com/pcr/demo-3/',
			),

			array(
				'import_file_name'			=> esc_html__( 'RTL', 'personal-cv-resume' ),
				
				'local_import_file'			=> trailingslashit( get_template_directory() ) . 'inc/demo-data/demo-4.xml',
				
				'local_import_widget_file'     => trailingslashit( get_template_directory() ) . 'inc/demo-data/demo-4.wie',
				
				'import_notice'				=> esc_html__( 'After import demo data, just set static homepage from settings > reading, check widgets & menus.', 'personal-cv-resume' ),
				'import_preview_image_url'     => 'https://demo.athemeart.com/pcr/img/demo-4.png',
				'preview_url'                => 'https://demo.athemeart.com/pcr/demo-4/',
			),
			
			
		);
		
		return apply_filters('personal_cv_resume_demo_import_files', $array);
	}
	add_filter( 'pt-ocdi/import_files', 'personal_cv_resume_demo_import_files' );
	
	
	
endif;

function personal_cv_resume_after_import_setup() {

	// Assign menus to their locations.
	$theme_option = 1;
	$main_menu 	  = array();

	if( !empty( get_term_by( 'name', 'Main Menu', 'nav_menu' ) ) ){
		$main_menu = get_term_by( 'name', 'Main Menu', 'nav_menu' );
	}elseif( !empty( get_term_by( 'name', 'Main Menu 2', 'nav_menu' ) ) ){
		$main_menu = get_term_by( 'name', 'Main Menu 2', 'nav_menu' );
	}elseif( !empty( get_term_by( 'name', 'Main Menu 3', 'nav_menu' ) ) ){
		$main_menu = get_term_by( 'name', 'Main Menu 3', 'nav_menu' );
	}elseif( !empty( get_term_by( 'name', 'Main Menu 4', 'nav_menu' ) ) ){
		$main_menu = get_term_by( 'name', 'Main Menu 4', 'nav_menu' );
	}
	
	set_theme_mod( 'nav_menu_locations', array(
			'menu-1' => $main_menu->term_id, 
		)
	);

	
	// Assign front page and posts page (blog page).
	$front_page_id = array();

	if( !empty( get_page_by_title( 'Home' ) ) ){
		$front_page_id = get_page_by_title( 'Home' );
	}

	$blog_page_id  = get_page_by_title( 'Blog' );

	update_option( 'show_on_front', 'page' );

	update_option( 'page_on_front', $front_page_id->ID );
	update_option( 'page_for_posts', $blog_page_id->ID );
	
	
	if( !empty( get_term_by( 'name', 'Main Menu', 'nav_menu' ) ) ){
		require get_template_directory() . '/inc/demo-data/theme-options-1.php';
	}elseif( !empty( get_term_by( 'name', 'Main Menu 2', 'nav_menu' ) ) ){
		require get_template_directory() . '/inc/demo-data/theme-options-2.php';
	}elseif( !empty( get_term_by( 'name', 'Main Menu 3', 'nav_menu' ) ) ){
		require get_template_directory() . '/inc/demo-data/theme-options-3.php';
	}elseif( !empty( get_term_by( 'name', 'Main Menu 4', 'nav_menu' ) ) ){
		require get_template_directory() . '/inc/demo-data/theme-options-4.php';
	}

}
add_action( 'pt-ocdi/after_import', 'personal_cv_resume_after_import_setup' );