<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package Personal_CV_Resume
 */
get_header();

$layout = 'full-container';
/**
* Hook - personal_cv_resume_container_wrap_start 	
*
* @hooked personal_cv_resume_container_wrap_start	- 5
*/
 do_action( 'personal_cv_resume_container_wrap_start',  esc_attr( $layout ) );

?>
<section class="error-404 not-found8">
 
    <div class="page-content text-center">
    
         <?php echo personal_cv_resume_get_option('__404_hero_text'); ?>
         <?php get_search_form();?>
        
     
        <div class="clearfix"></div>
        <!-- .widget -->

    </div><!-- .page-content -->
</section>

<?php
		
/**
* Hook - personal_cv_resume_container_wrap_end	
*
* @hooked container_wrap_end - 999
*/
 do_action( 'personal_cv_resume_container_wrap_end',  esc_attr( $layout ) );
get_footer();