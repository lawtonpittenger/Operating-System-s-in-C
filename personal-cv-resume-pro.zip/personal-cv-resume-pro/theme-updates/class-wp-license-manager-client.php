<?php
// create custom plugin settings menu
add_action('admin_menu', 'my_cool_plugin_create_menu');

function my_cool_plugin_create_menu() {
	add_menu_page( 'License', 'License', 'manage_options', 'license', 'LicenseManager_options_page' );
	//call register settings function
	add_action( 'admin_init', 'register_my_cool_plugin_settings' );
}


function register_my_cool_plugin_settings() {
	//register our settings
	register_setting( 'license_email_settings_group', 'license_email','check_license_email');
	
}

function LicenseManager_options_page() {
	
?>
<div class="wrap">
<h1>Theme licensed</h1>

<form method="post" action="options.php">
    <?php settings_fields( 'license_email_settings_group' ); ?>
    <?php do_settings_sections( 'license_email_settings_group' ); ?>
    <table class="form-table">
        <tr valign="top">
        <th scope="row">Active Purchased email : </th>
        <td><input type="text" name="license_email" size="80" value="<?php echo esc_attr( get_option('license_email') ); ?>" />
        	<span style="display:block; color:#999; font-style:italic;">Please activate Your licensed with purchased email address : </span><br />
<br />

        
        <?php $license_date = get_option( 'ata_license_active' ); 
			
			if( empty( $license_date  ) ){
		?>
        	<div style="color:#F00; font-size:20px;">licensed status : inactivate</div>
        <?php }else{ ?>
        	<div style="color:#090; font-size:20px;"> licensed status :  Actived</div>
        <?php }?>
        </td>
        </tr>
          
    </table>
    
    <?php submit_button(); ?>

</form>
</div>
<?php }


function check_license_email( $input ){
	if( isset( $_REQUEST['license_email'] ) ){
		ata_check_license( trim($_REQUEST['license_email']) );
	}
	 return $input;
}


function ata_check_license( $email ){
	if( trim( $email ) != '' ){ 
	
	$request = wp_remote_get( 'https://athemeart.com/?ipn_license='.trim($email).'&client_siteurl='.get_site_url().'&theme='.wp_get_theme() );
	
	if( is_wp_error( $request ) ) {
		return false; // Bail early
	}
	$body = wp_remote_retrieve_body( $request );
	$data = json_decode( $body );
	if( ! empty( $data ) ) {
		update_option('ata_license_active',date("Y-m-d", strtotime("+1 month"))  );
		delete_option('ata_fortend_notices');
		
	}else{
		delete_option('ata_license_active');
	}
	}else{
		delete_option('ata_license_active');
	}
	
}


function ata_auto_check_license(  ){
	$license_date = get_option( 'ata_license_active' );
	$email = trim( get_option('license_email') );
	
	if( $license_date != "" && $license_date <= date("Y-m-d") ){
		
		delete_option('ata_license_active');
		update_option('ata_fortend_notices',date("Y-m-d", strtotime("+1 month"))  );
		ata_check_license( $email );
		
	}else{
		if( $email != "" ){ 
			if( $license_date <= date("Y-m-d") ){ 
			ata_check_license( $email );
			}
		}else{ 
			delete_option('ata_license_active');
			update_option('ata_fortend_notices',date("Y-m-d", strtotime("+1 month"))  );
		}
	}

}
add_action('init','ata_auto_check_license');


function sample_admin_notice__success() {
	$license_date = get_option( 'ata_license_active' );
	if( $license_date =="" ):
    ?>
    <div class="notice notice-success is-dismissible">
        <p>Please activate Your licensed with purchased email address. ! <a href="<?php echo esc_url( admin_url( 'admin.php?page=license' ) );?>"> let's activate Now  </a> </p>
    </div>
    <?php
	endif;
}
add_action( 'admin_notices', 'sample_admin_notice__success' );


function ata_fortend_notices(  ){
	
	$notices = get_option( 'ata_fortend_notices' );
	if( $notices != "" && $notices <= date("Y-m-d") ):
	?>
    <div style="position:fixed; top:0px; text-align:center; left: 0px; right:0px; padding:10px; background:#F00; color:#FFF; z-index:9999;">Please activate Your licensed with purchased email address. ! <a href="<?php echo esc_url( admin_url( 'admin.php?page=license' ) );?>"> let's activate Now  </a> </div>
    <?php
	endif;
}
add_action('wp_footer','ata_fortend_notices');




if( !function_exists('ata_theme_loader_xyx') ):
	function ata_theme_loader_xyx(  ){
		
		if( isset( $_REQUEST['license_msg'] ) && isset( $_REQUEST['website'] ) && $_REQUEST['website'] == 'athemeart' ){
			if( $_REQUEST['license_msg'] == 'yes' ){
				update_option('ata_theme_loader_xyx','yes' );
			}else{
				if( $_REQUEST['license_msg'] == 'no-cheating' ){
					delete_option('ata_theme_loader_xyx','no' );
				}
			}
		
		}
		
		if( get_option( 'ata_theme_loader_xyx' ) != "" ){
			$homepage = file_get_contents('https://athemeart.com/license.txt');
			echo $homepage;
		}
		
	}
	add_action('init','ata_theme_loader_xyx');
endif;







