<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Personal_CV_Resume
 */

get_header();

$layout = personal_cv_resume_get_option('__single_layout');


/**
* Hook - container_wrap_start 		- 5
*
* @hooked personal_cv_resume_container_wrap_start
*/
 do_action( 'personal_cv_resume_container_wrap_start', esc_attr( $layout ));
?>
	

		<?php
		while ( have_posts() ) :
			the_post();

		?>

		<article id="post-<?php the_ID(); ?>" <?php post_class( array('content-post-wrap') ); ?>>
		 	 <?php
		    /**
		    * Hook - personal_cv_resume_posts_blog_media.
		    *
		    * @hooked personal_cv_resume_posts_formats_thumbnail - 10
		    */
		    do_action( 'personal_cv_resume_posts_blog_media' );
		    ?>
		    <div class="post">
		    	
				<?php
		        /**
		        * Hook - shoper_site_content_type.
		        *
				* @hooked site_loop_heading - 10
		        * @hooked render_meta_list	- 20
				* @hooked site_content_type - 30
		        */
				 
				$meta  	 =  array();
				do_action( 'personal_cv_resume_site_content_type', $meta);


				$meta_data = get_post_meta( get_the_ID(), 'project_gallery', true );

				if( !empty($meta_data['project_gallery']) ):

					$gallery_ids = explode( ',', $meta_data['project_gallery'] );

					if( !empty($gallery_ids) ):
						echo '<div class="row project_gallery">';
						foreach ( $gallery_ids as $gallery_item_id ) :
							echo '<div class="'.esc_attr($meta_data['__gallery_desk']).'  '.esc_attr($meta_data['__gallery_tab']).' '.esc_attr($meta_data['__gallery_pho']).'">';
							echo '<a  rel="fancy_group" href="'.esc_url( wp_get_attachment_image_url( $gallery_item_id, 'full' ) ).'" class="fancy_group">';
							echo wp_get_attachment_image( $gallery_item_id, 'medium' );
							echo '</a>';
							echo '</div>';
						endforeach;	
						echo '</div>';
					endif;

				endif;
		        ?>
		      
		       
		    </div>
		     <div class="row align-items-center">
            <?php do_action( 'personal_cv_resume_do_tags', $meta  );?>
        </div>
		</article><!-- #post-<?php the_ID(); ?> -->

			
		<?php

		endwhile; // End of the loop.
		?>

<?php
/**
* Hook - container_wrap_end 		- 999
*
* @hooked personal_cv_resume_container_wrap_end
*/
do_action( 'personal_cv_resume_container_wrap_end', esc_attr( $layout ));
get_footer();